# lab03

The features described in [lab02](https://github.com/androidmaycry/lab02/blob/master/README.md) has been improved using Firebase and FirebaseUI (in order to manage in a good way the recycler view).

Some additional feautures has been also added:
  - Login, signup and logout
  - Notification between the three different APPs: the **customer** make an order, the **restaurateur** accept it and send notificaiton to the **rider** with the related informations
