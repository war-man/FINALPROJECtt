package project.talentrecog;


import android.content.Context;
import android.util.Log;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

/**
 * Created by Amit on 3/17/2015.
 */
public class XmlParser {
    public Document getXmlDom(String xml) throws Exception {
        Document doc = null;
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        try {
            DocumentBuilder db = dbf.newDocumentBuilder();
            InputSource is = new InputSource();
            is.setCharacterStream(new StringReader(xml));
            doc = db.parse(is);
        } catch (ParserConfigurationException ex) {
            Log.e("Error: ", ex.getMessage());
            throw ex;
        } catch (SAXException ex) {
            Log.e("Error: ", ex.getMessage());
            throw ex;
        } catch (IOException ex) {
            Log.e("Error: ", ex.getMessage());
            throw ex;
        }
        return doc;
    }

    public String getXmlFromFileResource(Context context, int fileResId) throws IOException {
        String xmlstr = "";
        try {
            InputStream is = context.getResources().openRawResource(fileResId);
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            StringBuilder sb = new StringBuilder();
            String line = null;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }
            reader.close();
            is.close();
            xmlstr = sb.toString();
        } catch (IOException ioe) {
            throw ioe;
        }
        return xmlstr;
    }
}
