package project.talentrecog;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import project.talentrecog.R;
import project.talentrecog.entities.User;


public class NewUserActivity extends ActionBarActivity {

    private EditText edtUsername;
    private EditText edtAge;
    private Spinner spnGender;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_user);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_user_details, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    public void startTestClicked(View view){
        try {
            DatabaseAdapter dba = new DatabaseAdapter(getApplicationContext());
            dba.open(false);
            edtUsername=(EditText)findViewById(R.id.edtName);
            edtAge=(EditText)findViewById(R.id.edtAge);
            spnGender=(Spinner)findViewById(R.id.spnGender);
            User u=new User();
            u.setUserName(edtUsername.getText().toString());
            u.setAge(Integer.parseInt(edtAge.getText().toString()));
            u.setGender(spnGender.getSelectedItem().toString());
            dba.insertUser(u);
            u.setId(dba.getLastCreatedUserId());
            dba.close();
            Intent intent = new Intent(getApplicationContext(), StartTestActivity.class);
            intent.putExtra("userdata",u.getUserData());
            startActivity(intent);
        }catch(DatabaseAdapter.AdapterException ex){
            Toast.makeText(getApplicationContext(),ex.getMessage(),Toast.LENGTH_LONG).show();
        }

    }
}
