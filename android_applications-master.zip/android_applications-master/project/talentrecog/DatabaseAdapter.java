package project.talentrecog;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import project.talentrecog.R;
import project.talentrecog.entities.Question;
import project.talentrecog.entities.Test;
import project.talentrecog.entities.Answer;
import project.talentrecog.entities.TestResult;
import project.talentrecog.entities.User;

//Usage
// DatabaseAdapter dba = new DatabaseAdapter(contextObjecT);
// dba.open();
// dba.insert(...);
// dba.close();
public class DatabaseAdapter {
    private static final String DATABASE_PATH = "/data/data/project.talentrecog/databases/";
    private static final String DATABASE_NAME = "talentdb2";
    private static final int DATABASE_VERSION = 21;
    private static SQLiteDatabase db;
    private DatabaseOpenHelper dbOpenHelper;
    private Context adapterContext;

    public DatabaseAdapter(Context context) {
        this.adapterContext = context;

    }

    private boolean checkIfDatabaseExists() {
        SQLiteDatabase checkDB = null;
        try {
            String myPath = DATABASE_PATH + DATABASE_NAME;
            checkDB = SQLiteDatabase.openDatabase(myPath, null,
                    SQLiteDatabase.OPEN_READONLY);
        } catch (SQLiteException e) {
        }
        if (checkDB != null) {
            checkDB.close();
        }
        return checkDB != null ? true : false;
    }

    private void copyDatabaseFromFile() throws IOException {
        // Open your local db as the input stream
        InputStream myInput = adapterContext.getAssets().open(DATABASE_NAME);
        // Path to the just created empty db
        String outFileName = DATABASE_PATH + DATABASE_NAME;
        // Open the empty db as the output stream
        OutputStream myOutput = new FileOutputStream(outFileName);
        // transfer bytes from the inputfile to the outputfile
        byte[] buffer = new byte[1024];
        int length;
        while ((length = myInput.read(buffer)) > 0) {
            myOutput.write(buffer, 0, length);
        }
        // Close the streams
        myOutput.flush();
        myOutput.close();
        myInput.close();
    }

    private void createDatabase(boolean isFromFile) throws IOException {
        boolean dbExist = checkIfDatabaseExists();
        if (!dbExist) {
            dbOpenHelper.getWritableDatabase();
            if (isFromFile) {
                try {
                    copyDatabaseFromFile();
                } catch (IOException e) {
                    throw new Error("Error copying database");
                }
            }
        }
    }

    private void openDatabase() throws SQLException {
        String myPath = DATABASE_PATH + DATABASE_NAME;
        db = SQLiteDatabase.openDatabase(myPath, null,
                SQLiteDatabase.OPEN_READWRITE);
    }

    public DatabaseAdapter open(boolean isFromFile) throws AdapterException {
        try {
            dbOpenHelper = new DatabaseOpenHelper(adapterContext);
            db = dbOpenHelper.getWritableDatabase();
        /*try {
            createDatabase(isFromFile);
        } catch (IOException ioe) {
            throw new Exception("Unable to create database");
        }
        try {
            openDatabase();
        } catch (SQLException sqle) {
            throw new Exception("Unable to open database");
        }*/
        } catch (Exception ex) {
            throw new AdapterException(ex.getMessage());
        }
        return this;
    }

    public SQLiteDatabase getDatabase() {
        String myPath = DATABASE_PATH + DATABASE_NAME;
        return SQLiteDatabase.openDatabase(myPath, null,
                SQLiteDatabase.OPEN_READONLY);
    }

    public void close() {
        if (db != null) {
            db.close();
            db = null;
        }
    }

    //Convenience Methods
    public int getQuestionCountByLevel(int level) {
        String query = "Select count(*) from questions where level=?";
        Cursor c = db.rawQuery(query, new String[]{String.valueOf(level)});
        int count = 0;
        if (c.getCount() > 0) {
            count = c.getInt(0);
        }
        return count;
    }

    public ArrayList<Question> getQuestionsByLevel(int level) {
        String query = "Select questions._id,questions.question,questions.category,questions.level,questions.tag " +
                "from questions where questions.level=?";
        Cursor questionsCursor = db.rawQuery(query, new String[]{String.valueOf(level)});
        int qno = 1;
        ArrayList<Question> questions = new ArrayList<>();
        questionsCursor.moveToFirst();
        while (!questionsCursor.isAfterLast()) {
            Question q = new Question();
            q.setId(questionsCursor.getInt(0));
            q.setQuestion(questionsCursor.getString(1));
            q.setCategory(questionsCursor.getString(2));
            q.setLevel(questionsCursor.getInt(3));
            q.setTag(questionsCursor.getString(4));
            q.setQno(qno);
            qno++;
            query = "Select options.option,options.mark " +
                    "from options where options.qid=? ORDER BY options._id";
            Cursor optionsCursor = db.rawQuery(query, new String[]{String.valueOf(q.getId())});
            HashMap<String, Float> options = new HashMap<>();
            optionsCursor.moveToFirst();
            while (!optionsCursor.isAfterLast()) {
                options.put(optionsCursor.getString(0), optionsCursor.getFloat(1));
                optionsCursor.moveToNext();
            }
            q.setOptions(options);
            questions.add(q);
            questionsCursor.moveToNext();
        }
        return questions;
    }
    public ArrayList<Question> getQuestionsByLevelAndCategory(int level,String category) {
        String query = "Select questions._id,questions.question,questions.category,questions.level,questions.tag " +
                "from questions where questions.level=?";
        Cursor questionsCursor = db.rawQuery(query, new String[]{String.valueOf(level)});
        int qno = 1;
        ArrayList<Question> questions = new ArrayList<>();
        questionsCursor.moveToFirst();
        while (!questionsCursor.isAfterLast()) {
            Question q = new Question();
            q.setId(questionsCursor.getInt(0));
            q.setQuestion(questionsCursor.getString(1));
            q.setCategory(questionsCursor.getString(2));
            q.setLevel(questionsCursor.getInt(3));
            q.setTag(questionsCursor.getString(4));
            q.setQno(qno);
            qno++;
            query = "Select options.option,options.mark " +
                    "from options where options.qid=? ORDER BY options._id";
            Cursor optionsCursor = db.rawQuery(query, new String[]{String.valueOf(q.getId())});
            HashMap<String, Float> options = new HashMap<>();
            optionsCursor.moveToFirst();
            while (!optionsCursor.isAfterLast()) {
                options.put(optionsCursor.getString(0), optionsCursor.getFloat(1));
                optionsCursor.moveToNext();
            }
            q.setOptions(options);
            questions.add(q);
            questionsCursor.moveToNext();
        }
        return questions;
    }
    public Question getQuestionById(int id) {
        String query = "Select questions.id,questions.question,questions.category,questions.level,questions.inputType " +
                "from questions where questions.id=?";
        Cursor questionsCursor = db.rawQuery(query, new String[]{String.valueOf(id)});
        Question q = null;
        if (questionsCursor.getCount() > 0) {
            questionsCursor.moveToFirst();
            q = new Question();
            q.setId(questionsCursor.getInt(0));
            q.setQuestion(questionsCursor.getString(1));
            q.setCategory(questionsCursor.getString(2));
            q.setTag(questionsCursor.getString(3));
            questionsCursor.close();
            query = "Select options.option,options.mark " +
                    "from options where options.qid=?";
            Cursor optionsCursor = db.rawQuery(query, new String[]{String.valueOf(id)});
            HashMap<String, Float> options = new HashMap<>();
            optionsCursor.moveToFirst();
            while (!optionsCursor.isAfterLast()) {
                options.put(optionsCursor.getString(0), optionsCursor.getFloat(1));
                optionsCursor.moveToNext();
            }
            optionsCursor.close();
            q.setOptions(options);
        }
        return q;
    }

    //User Management
    public void insertUser(User user) throws AdapterException {
        ContentValues values = new ContentValues();
        values.putNull("_id");
        values.put("username", user.getUserName());
        values.put("age", user.getAge());
        values.put("gender", user.getGender());
        long result = db.insert("users", null, values);
        if (result == -1)
            throw new AdapterException("Failed to create user");
    }

    public int getLastCreatedUserId() throws AdapterException{
        int uid=-1;
        try{
            String query="select MAX(_id) from users";
            Cursor c=db.rawQuery(query,null);
            if(c.getCount()>0){
                c.moveToFirst();
                uid=c.getInt(0);
            }
        } catch (Exception ex) {
            throw new AdapterException(new SQLException("Failed to retrieve data"));
        }
        return uid;
    }
    public int getLastCreatedTestId() throws AdapterException{
        int uid=-1;
        try{
            String query="select MAX(_id) from tests";
            Cursor c=db.rawQuery(query,null);
            if(c.getCount()>0){
                c.moveToFirst();
                uid=c.getInt(0);
            }
        } catch (Exception ex) {
            throw new AdapterException(new SQLException("Failed to retrieve data"));
        }
        return uid;
    }
    public User getUserByUsername(String username) throws AdapterException {
        User u= null;
        try {
            String query = "select * from users where username=?";
            Cursor c = db.rawQuery(query, new String[]{username});
            if (c.getCount() > 0) {
                c.moveToFirst();
                u=new User();
                u.setId(c.getInt(0));
                u.setUserName(c.getString(1));
                u.setAge(c.getInt(2));
                u.setGender(c.getString(3));
            }
            c.close();
        } catch (Exception ex) {
            throw new AdapterException(new SQLException("Failed to retrieve data"));
        }
        return u;
    }


    public boolean isUserExists(String username) throws AdapterException {
        boolean isUserExists = false;
        try {
            String query = "select count(*) from users where username=?";
            Cursor c = db.rawQuery(query, new String[]{username});
            if (c.getCount() > 0) {
                c.moveToFirst();
                int count = c.getInt(0);
                isUserExists = count == 1;
            }
            c.close();
        } catch (Exception ex) {
            throw new AdapterException(new SQLException("Failed to retrieve data"));
        }
        return isUserExists;
    }

    public void insertQuestion(Question q) throws AdapterException {
        ContentValues qValues = new ContentValues();
        qValues.putNull("_id");
        qValues.put("question", q.getQuestion());
        qValues.put("category", q.getCategory());
        qValues.put("level", q.getLevel());
        qValues.put("tag", q.getTag());
        long qresult = db.insert("Questions", null, qValues);
        if (qresult == -1)
            throw new AdapterException(new SQLException("Failed to insert row"));
        Cursor c = db.rawQuery("select MAX(_id) as qid from Questions", null);
        String qid = "";
        if (c.getCount() > 0) {
            c.moveToFirst();
            qid = c.getString(0);
        }
        c.close();
        Iterator<String> iteOpts = q.getOptions().keySet().iterator();
        while (iteOpts.hasNext()) {
            String key = iteOpts.next();
            ContentValues oValues = new ContentValues();
            oValues.putNull("_id");
            oValues.put("qid", qid);
            oValues.put("option", key);
            oValues.put("mark", q.getOptions().get(key));
            long oresult = db.insert("Options", null, oValues);
            if (oresult == -1)
                throw new AdapterException(new SQLException("Failed to insert row"));
        }
    }

    public void insertTest(Test t) throws AdapterException {
        ContentValues values = new ContentValues();
        values.putNull("_id");
        values.put("uid", t.getUid());
        values.put("tdate",t.getTestDate().getTime().toString());
        values.put("status", t.getStatus());
        long result = db.insert("Tests", null, values);
        if (result == -1)
            throw new AdapterException(new SQLException("Failed to insert row"));
    }

    public void insertAnswer(Answer ans) throws AdapterException {
        ContentValues values = new ContentValues();
        values.putNull("_id");
        values.put("tid", ans.getTid());
        values.put("qid", ans.getQid());
        values.put("score", ans.getScore());
        long result = db.insert("Answers", null, values);
        if (result == -1)
            throw new AdapterException(new SQLException("Failed to insert row"));
    }

    public TestResult getTestResult(int testid) throws AdapterException{
        TestResult tr = null;
        try {
            tr=new TestResult();
            String query1 = "select users.username,users.age,users.gender,tests.tdate,tests.status " +
                    "from users join tests on tests.uid=users._id where tests._id=?";
            Cursor cursor1 = db.rawQuery(query1, new String[]{String.valueOf(testid)});
            cursor1.moveToFirst();
            if (cursor1.getCount() > 0) {
                tr.setUsername(cursor1.getString(0));
                tr.setAge(cursor1.getInt(1));
                tr.setGender(cursor1.getString(2));
                tr.setTestDate(cursor1.getString(3));
                tr.setTestStatus(cursor1.getString(4));
            }
            cursor1.close();
            String query2 = "select questions.category,(SUM(answers.score)/COUNT(category))*100 as Score, MAX(questions.level) as Level " +
                    "from answers join questions on answers.qid=questions._id where answers.tid=? GROUP BY questions.category";
            Cursor cursor2 = db.rawQuery(query2, new String[]{String.valueOf(testid)});
            cursor2.moveToFirst();
            LinkedHashMap<String, Float> scores = new LinkedHashMap<>();
            while (!cursor2.isAfterLast()) {
                scores.put(cursor2.getString(0), cursor2.getFloat(1));
                tr.setLevel(cursor2.getInt(2));
                cursor2.moveToNext();
            }
            tr.setScores(scores);
        }catch (Exception ex){
            throw new AdapterException(ex);
        }
        return tr;
    }

static class AdapterException extends Exception {
    private String message;
    private Throwable innerException;

    public AdapterException() {
        super();
        this.message = "There was an error in the database operation.";
        Log.e("AdapterException", this.message);
    }

    public AdapterException(String message) {
        super(message);
        this.message = message;
        Log.e("AdapterException", message);
    }

    public AdapterException(Throwable innerException) {
        super(innerException);
        this.message = "There was an error in the database operation.";
        this.innerException = innerException;
        Log.e("AdapterException", innerException.getMessage());
    }

    public AdapterException(String message, Throwable innerException) {
        super(message, innerException);
        this.message = message;
        this.innerException = innerException;
        Log.e("AdapterException", innerException.getMessage());
    }

    @Override
    public String getMessage() {
        return this.message;
    }

    @Override
    public Throwable getCause() {
        return this.innerException;
    }
}

private static class DatabaseOpenHelper extends SQLiteOpenHelper {
    Context helperContext;

    private static final String CREATE_USERS_TABLE = "CREATE TABLE users " +
            "(_id INTEGER PRIMARY KEY," +
            "username TEXT UNIQUE NOT NULL," +
            "age INTEGER NOT NULL," +
            "gender TEXT NOT NULL);";
    private static final String CREATE_QUESTIONS_TABLE = "CREATE TABLE questions " +
            "(_id INTEGER PRIMARY KEY," +
            "question TEXT NOT NULL," +
            "category TEXT NOT NULL," +
            "level INTEGER NOT NULL," +
            "tag TEXT);";
    private static final String CREATE_OPTIONS_TABLE = "CREATE TABLE options " +
            "(_id INTEGER PRIMARY KEY," +
            "qid INTEGER NOT NULL REFERENCES questions(_id)," +
            "option TEXT NOT NULL," +
            "mark FLOAT NOT NULL);";
    private static final String CREATE_TEST_TABLE = "CREATE TABLE tests " +
            "(_id INTEGER PRIMARY KEY," +
            "uid TEXT NOT NULL REFERENCES users(_id)," +
            "tdate DATE NOT NULL, " +
            "status TEXT NOT NULL);";
    private static final String CREATE_ANSWERS_TABLE = "CREATE TABLE answers " +
            "(_id INTEGER PRIMARY KEY," +
            "tid INTEGER NOT NULL REFERENCES tests(_id)," +
            "qid INTEGER NOT NULL REFERENCES questions(_id)," +
            "score FLOAT NOT NULL);";

    DatabaseOpenHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.helperContext = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            db.execSQL(CREATE_USERS_TABLE);
            db.execSQL(CREATE_QUESTIONS_TABLE);
            db.execSQL(CREATE_OPTIONS_TABLE);
            db.execSQL(CREATE_TEST_TABLE);
            db.execSQL(CREATE_ANSWERS_TABLE);

            insertRowsToQuestionsTable(db);
        } catch (SQLException ex) {
            Log.e("onCreate", ex.getMessage());
        }
    }

    private void insertRowsToQuestionsTable(SQLiteDatabase db) {
        ArrayList<Question> alQ = getInsertDataForQuestionsTableFromXmlResource();
        for (Question q : alQ) {
            ContentValues qValues = new ContentValues();
            qValues.putNull("_id");
            qValues.put("question", q.getQuestion());
            qValues.put("category", q.getCategory());
            qValues.put("level", q.getLevel());
            qValues.put("tag", q.getTag());
            long qrowid = db.insert("Questions", null, qValues);
            Cursor c = db.rawQuery("select MAX(_id) as qid from Questions", null);
            String qid = "";
            if (c.getCount() > 0) {
                c.moveToFirst();
                qid = c.getString(0);
            }
            c.close();
            Iterator<String> iteOpts = q.getOptions().keySet().iterator();
            while (iteOpts.hasNext()) {
                String key = iteOpts.next();
                ContentValues oValues = new ContentValues();
                oValues.putNull("_id");
                oValues.put("qid", qid);
                oValues.put("option", key);
                oValues.put("mark", q.getOptions().get(key));
                long orowid = db.insert("Options", null, oValues);
            }
        }
    }

    private ArrayList<Question> getInsertDataForQuestionsTableFromXmlResource() {
        final String TAG_QUESTION = "question";
        final String ATT_DESC = "desc";
        final String ATT_CATEGORY = "category";
        final String ATT_LEVEL = "level";
        final String ATT_TAG = "tag";

        final String ATT_OPT = "opt";
        final String ATT_MARK = "mark";
        ArrayList<Question> questions = new ArrayList<>();
        try {
            XmlParser parser = new XmlParser();
            String xml = parser.getXmlFromFileResource(helperContext, R.raw.questions);
            Document doc = parser.getXmlDom(xml);

            NodeList qList = doc.getElementsByTagName(TAG_QUESTION);

            for (int i = 0; i < qList.getLength(); i++) {
                Element qNode = (Element) qList.item(i);
                String desc = qNode.getAttribute(ATT_DESC);
                String cat = qNode.getAttribute(ATT_CATEGORY);
                String level = qNode.getAttribute(ATT_LEVEL);
                String tag = qNode.getAttribute(ATT_TAG);
                Question q = new Question();
                q.setQuestion(desc);
                q.setCategory(cat);
                q.setLevel(Integer.parseInt(level));
                q.setTag(tag);
                HashMap<String, Float> options = new HashMap<>();
                NodeList oList = qNode.getElementsByTagName("option");
                for (int j = 0; j < oList.getLength(); j++) {
                    Element oNode = (Element) oList.item(j);
                    String opt = oNode.getAttribute(ATT_OPT);
                    String mark = oNode.getAttribute(ATT_MARK);
                    options.put(opt, Float.parseFloat(mark));
                }
                q.setOptions(options);
                questions.add(q);
            }

        } catch (Exception ex) {
            Log.e("error:", ex.getMessage());
        }
        return questions;
    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS Users");
        db.execSQL("DROP TABLE IF EXISTS Options");
        db.execSQL("DROP TABLE IF EXISTS Questions");
        db.execSQL("DROP TABLE IF EXISTS Tests");
        db.execSQL("DROP TABLE IF EXISTS Answers");
        onCreate(db);
    }
}
}