package project.talentrecog.entities;

import java.util.HashMap;


public class Question {
    private int id;
    private int qno;
    private String question;
    private String category;
    private int level;
    private String tag;
    private HashMap<String,Float> options;
    private boolean isAnswered;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getCategory() {
        return category;
    }


    public void setCategory(String category) {
        this.category = category;
    }

    public HashMap<String, Float> getOptions() {
        return options;
    }

    public void setOptions(HashMap<String, Float> options) {
        this.options = options;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public boolean isAnswered() {
        return isAnswered;
    }

    public void setAnswered(boolean isAnswered) {
        this.isAnswered = isAnswered;
    }

    public int getQno() {
        return qno;
    }

    public void setQno(int qno) {
        this.qno = qno;
    }
}
