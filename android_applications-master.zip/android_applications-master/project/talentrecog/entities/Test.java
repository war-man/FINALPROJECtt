package project.talentrecog.entities;

import java.util.Calendar;

/**
 * Created by Amit on 3/20/2015.
 */
public class Test {
    public static final String STARTED="Started";
    public static final String SAVED="Saved";
    public static final String COMPLETED="Completed";
    public static final int MAX_LEVEL=3;

    private int id;
    private int uid;
    private String username;
    private Calendar testDate;
    private String status;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Calendar getTestDate() {
        return testDate;
    }

    public void setTestDate(Calendar testDate) {
        this.testDate = testDate;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }
}
