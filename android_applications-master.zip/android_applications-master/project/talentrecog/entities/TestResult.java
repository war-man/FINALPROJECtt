package project.talentrecog.entities;

import java.util.LinkedHashMap;

/**
 * Created by Amit on 3/20/2015.
 */
public class TestResult {
    private String username;
    private int age;
    private String gender;
    private int level;
    private String testDate;
    private  String testStatus;
    private String inference;
    private LinkedHashMap<String,Float> scores;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public String getInference() {
        return inference;
    }

    public void setInference(String inference) {
        this.inference = inference;
    }

    public LinkedHashMap<String, Float> getScores() {
        return scores;
    }

    public void setScores(LinkedHashMap<String, Float> scores) {
        this.scores = scores;
    }

    public String getTestStatus() {
        return testStatus;
    }

    public void setTestStatus(String testStatus) {
        this.testStatus = testStatus;
    }

    public String getTestDate() {
        return testDate;
    }

    public void setTestDate(String testDate) {
        this.testDate = testDate;
    }
}
