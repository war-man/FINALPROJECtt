package project.talentrecog.entities;

/**
 * Created by Amit on 3/10/2015.
 */
public class User {
    private int id;
    private String userName;
    private int age;
    private String gender;

    public String[] getUserData(){
        String[] userdata=new String[4];
        userdata[0]=String.valueOf(getId());
        userdata[1]=getUserName();
        userdata[2]=String.valueOf(getAge());
        userdata[3]=getGender();
        return userdata;
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }
}
