package project.talentrecog;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.media.MediaPlayer;
import android.os.Handler;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Random;

import project.talentrecog.R;
import project.talentrecog.entities.Answer;
import project.talentrecog.entities.Question;
import project.talentrecog.entities.Test;
import project.talentrecog.entities.TestResult;


public class StartTestActivity extends ActionBarActivity implements Runnable {
    boolean isTestInitialized = false;
    Test test;
    ArrayList<Answer> answers;
    ViewFlipper vf;
    TextView tv;
    Button btnNext;
    TextView tvLevel;
    MediaPlayer mplayer;
    Thread t;

    Context context;
    DatabaseAdapter dba;
    ArrayList<Question> questions;
    ArrayList<Question> rQuestions;
    ArrayList<Question> sQuestions;
    Iterator itQuestions;
    Question currentQuestion;
    float ansScore;
    int currentLevel = 0;
    int currentQno;

    String toastMessage = "";
    final Handler handler = new Handler();
    final Runnable showToastMessage = new Runnable() {
        public void run() {
            Toast.makeText(getApplicationContext(), toastMessage, Toast.LENGTH_LONG).show();
        }
    };
    int displayChildIndex = 0;

    final Runnable showLoadingView = new Runnable() {
        @Override
        public void run() {
            tvLevel.setVisibility(View.INVISIBLE);
            btnNext.setVisibility(View.INVISIBLE);
            vf.setDisplayedChild(0);
        }
    };
    final Runnable showFinishView = new Runnable() {
        @Override
        public void run() {
            tvLevel.setVisibility(View.INVISIBLE);
            btnNext.setVisibility(View.INVISIBLE);
            vf.setDisplayedChild(5);
        }
    };
    final Runnable showInputView = new Runnable() {
        @Override
        public void run() {
            tvLevel.setVisibility(View.VISIBLE);
            btnNext.setVisibility(View.VISIBLE);
            vf.setDisplayedChild(displayChildIndex);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_test);

        tvLevel = (TextView) findViewById(R.id.txtTestLevel);
        btnNext = (Button) findViewById(R.id.btnNext);
        vf = (ViewFlipper) findViewById(R.id.viewFlipper);
        vf.setDisplayedChild(0);
        btnNext.setVisibility(View.INVISIBLE);
        context = getApplicationContext();
        test = new Test();
        int uid = Integer.parseInt(getIntent().getStringArrayExtra("userdata")[0]);
        test.setUid(uid);
        test.setTestDate(Calendar.getInstance());
        test.setStatus("Started");

        t = new Thread(this);
        t.start();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_start_test, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    public void showRedoSkippedMessageBox() {
        try {
            AlertDialog.Builder dlgAlert = new AlertDialog.Builder(this);
            dlgAlert.setTitle("Question");
            dlgAlert.setMessage("You have skipped questions." + System.getProperty("line.separator") + "Click 'YES' to re-ettempt or 'NO' to finish test.");
            dlgAlert.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int whichButton) {
                    chooseContinueAction(false);
                }
            });
            dlgAlert.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int whichButton) {
                    chooseContinueAction(true);
                }
            });

            dlgAlert.setCancelable(true);
            dlgAlert.create().show();
        } catch (Exception ex) {

            Toast.makeText(getApplicationContext(), ex.getMessage(), Toast.LENGTH_LONG).show();

        }
    }

    private void chooseContinueAction(boolean choice) {
        if (choice == true) {
            itQuestions = sQuestions.iterator();
            currentQuestion = getNextQuestion();
            showQuestion();
        }
    }

    private void finishTest() {
        TestResult tr = null;
        try {
            dba.open(false);
            for (Answer ans : answers) {
                dba.insertAnswer(ans);
            }
            tr = dba.getTestResult(test.getId());
            dba.close();

            handler.post(showFinishView);
            StringBuilder sbUserData = new StringBuilder();
            //String[] userdata=getIntent().getStringArrayExtra("userdata");
            sbUserData.append("User:" + tr.getUsername());
            sbUserData.append(System.getProperty("line.separator"));
            sbUserData.append("Age:" + tr.getAge());
            sbUserData.append(System.getProperty("line.separator"));
            sbUserData.append("Gender:" + tr.getGender());
            TextView txtUserData = (TextView) findViewById(R.id.txtUserDetails);
            txtUserData.setText(sbUserData.toString());

            StringBuilder sbChart = new StringBuilder();
            LinkedHashMap<String, Float> scores = tr.getScores();
            float musicScore = scores.get("Music")==null?0:(Float) scores.get("Music");
            float managementScore = scores.get("Management")==null?0:(Float) scores.get("Management");
            float investigationScore=scores.get("Investigation")==null?0:(Float)scores.get("Investigation");
            sbChart.append("Music:" + String.valueOf(Math.round(musicScore))+"%");
            sbChart.append(System.getProperty("line.separator"));
            sbChart.append("Management:" + String.valueOf(Math.round(managementScore))+"%");
            sbChart.append(System.getProperty("line.separator"));
            sbChart.append("Investigation:" + String.valueOf(investigationScore));
            TextView txtChart = (TextView) findViewById(R.id.txtChart);
            txtChart.setText(sbChart.toString());

            StringBuilder sbInference = new StringBuilder();
            sbInference.append("You are more talented in ");
            String talentarea = "";
            talentarea = musicScore > managementScore ? "Music." : "Management.";
            talentarea = managementScore>investigationScore?"Management.":"Investigation.";
            sbInference.append(talentarea);
            TextView txtInference = (TextView) findViewById(R.id.txtInference);
            txtInference.setText(sbInference.toString());
        } catch (Exception ex) {
            final String errmsg = ex.getMessage();
            handler.post(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(getApplicationContext(), errmsg, Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    @Override
    public void run() {
        try {
            if (currentLevel == Test.MAX_LEVEL) {
                finishTest();
                return;
            }
            currentLevel++;
            questions = loadQuestions(currentLevel);
            if (questions != null) {
                rQuestions = randomizeQuestions(questions);
                itQuestions = rQuestions.iterator();
                currentQuestion = getNextQuestion();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        showQuestion();
                    }
                });
            }
        } catch (Exception ex) {
            final String errmsg = ex.getMessage();
            handler.post(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(getApplicationContext(), errmsg, Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    private ArrayList<Question> loadQuestions(int level) {
        ArrayList<Question> alQ = null;
        try {
            dba = new DatabaseAdapter(context);
            dba.open(false);
            if (!isTestInitialized) {
                answers = new ArrayList<>();
                dba.insertTest(test);
                test.setId(dba.getLastCreatedTestId());
            }
            alQ = dba.getQuestionsByLevel(level);
            dba.close();
        } catch (Exception ex) {
            toastMessage = ex.getMessage();
            handler.post(showToastMessage);
        }
        return alQ;
    }

    private ArrayList<Question> randomizeQuestions(ArrayList<Question> alQ) {
        ArrayList<Question> alRQ = new ArrayList<>();
        try {
            while (alQ.size() > 0) {
                Random r = new Random(Calendar.getInstance().getTimeInMillis());
                int index = r.nextInt(alQ.size()) - 1;
                index = index < 0 ? 0 : index;
                Question q = alQ.get(index);
                alRQ.add(q);
                alQ.remove(index);
            }
        } catch (Exception ex) {
            final String errmsg = ex.getMessage();
            handler.post(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(getApplicationContext(), errmsg, Toast.LENGTH_LONG).show();
                }
            });
        }
        return alRQ.size() == 0 ? null : alRQ;
    }

    private ArrayList<Question> getSkippedQuestions() {
        ArrayList<Question> alSQ = new ArrayList<>();
        try {
            for (Question q : rQuestions) {
                if (!q.isAnswered())
                    alSQ.add(q);
            }
        } catch (Exception ex) {
            final String errmsg = ex.getMessage();
            handler.post(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(getApplicationContext(), errmsg, Toast.LENGTH_LONG).show();
                }
            });
        }
        return alSQ.size() == 0 ? null : alSQ;
    }

    private Question getNextQuestion() {
        Question q = null;
        try {
            if (itQuestions.hasNext()) {
                q = (Question) itQuestions.next();
                currentQno++;
            } else {
                currentQno = 0;
            }
        } catch (Exception ex) {
            final String errmsg = ex.getMessage();
            handler.post(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(getApplicationContext(), errmsg, Toast.LENGTH_LONG).show();
                }
            });
        }
        return q;
    }

    private void showQuestion() {
        try {
            if (currentQuestion.getCategory().toLowerCase().startsWith("man") ||
                    currentQuestion.getCategory().toLowerCase().startsWith("inv")) {
                displayChildIndex = 1;
                handler.post(showInputView);
                tvLevel.setText("Level " + currentLevel);

                String qstr = currentQno + "." + currentQuestion.getQuestion();
                TextView tv = (TextView) findViewById(R.id.txtTapV1Question);
                RadioGroup rg = (RadioGroup) findViewById(R.id.rdgTapV1Options);
                rg.removeAllViews();
                btnNext.setVisibility(View.VISIBLE);
                vf.setDisplayedChild(1);
                tv.setText(qstr);
                Iterator<String> ite = currentQuestion.getOptions().keySet().iterator();
                while (ite.hasNext()) {
                    String option = ite.next();
                    float mark = currentQuestion.getOptions().get(option);
                    final RadioButton rb = new RadioButton(rg.getContext());
                    rb.setText(option);
                    rb.setTag(mark);
                    rb.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            currentQuestion.setAnswered(true);
                            RadioButton rbt = (RadioButton) v;
                            ansScore = Float.parseFloat(rbt.getTag().toString());
                        }
                    });
                    rg.addView(rb);
                }
            } else if (currentQuestion.getCategory().toLowerCase().startsWith("mus")) {
                displayChildIndex = 2;
                handler.post(showInputView);
                tvLevel.setText("Level " + currentLevel);

                String qstr = currentQno + "." + currentQuestion.getQuestion();
                TextView tv = (TextView) findViewById(R.id.txtTapV2Question);
                RadioGroup rg = (RadioGroup) findViewById(R.id.rdgTapV2Options);
                rg.removeAllViews();
                btnNext.setVisibility(View.VISIBLE);
                vf.setDisplayedChild(2);
                tv.setText(qstr);
                Iterator<String> ite = currentQuestion.getOptions().keySet().iterator();
                while (ite.hasNext()) {
                    String option = ite.next();
                    float mark = currentQuestion.getOptions().get(option);
                    final RadioButton rb = new RadioButton(rg.getContext());
                    rb.setText(option);
                    rb.setTag(mark);
                    rb.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            currentQuestion.setAnswered(true);
                            RadioButton rbt = (RadioButton) v;
                            ansScore = Float.parseFloat(rbt.getTag().toString());
                        }
                    });
                    rg.addView(rb);
                }
                final int resourceId = this.getResources().getIdentifier(currentQuestion.getTag(), "raw", this.getPackageName());
                Button btnTapV2Replay=(Button)findViewById(R.id.btnTapV2Replay);
                btnTapV2Replay.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                       mplayer = MediaPlayer.create(getApplicationContext(), resourceId);
                        mplayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                            @Override
                            public void onCompletion(MediaPlayer mp) {

                            }
                        });
                        mplayer.start();
                    }
                });
                if (currentQuestion.getCategory().toLowerCase().startsWith("mus")) {
                    mplayer = MediaPlayer.create(getApplicationContext(), resourceId);
                    mplayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                        @Override
                        public void onCompletion(MediaPlayer mp) {

                        }
                    });
                    mplayer.start();
                }
            } else if (currentQuestion.getCategory().toLowerCase().startsWith("dra")) {
                vf.setDisplayedChild(3);
            } else if (currentQuestion.getCategory().toLowerCase().startsWith("lit")) {
                vf.setDisplayedChild(4);
            }
        } catch (Exception ex) {
            final String msg = ex.getMessage();
            handler.post(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    public void btnNextOnClick(View v) {
        try {
            if (mplayer != null && mplayer.isPlaying()) {
                mplayer.stop();
                mplayer = null;
            }

            Answer ans = new Answer();
            ans.setQid(currentQuestion.getId());
            ans.setTid(test.getId());
            ans.setScore(ansScore);
            answers.add(ans);

            currentQuestion = getNextQuestion();
            if (currentQuestion != null) {
                showQuestion();
            } else {
                sQuestions = getSkippedQuestions();
                if (sQuestions != null) {
                    showRedoSkippedMessageBox();
                } else {
                    if (t.isAlive())
                        t.interrupt();
                    t = new Thread(this);
                    t.start();
                }
            }
        } catch (Exception ex) {
            final String errmsg = ex.getMessage();
            handler.post(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(getApplicationContext(), errmsg, Toast.LENGTH_LONG).show();
                }
            });
        }
    }
}
