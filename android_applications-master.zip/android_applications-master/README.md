# android_applications
This repository has my final year bachelors project codes 

Right Path-An android application for talent recognition among teenagers
(Guide:Assistant Professor Remya Velayudhan. , jan’15 - may’15)
-a final year project under the CSE department, Amrita Vishwa Vidyapeetham, Kollam and Neurology
department, Amrita Institute of Medical Science (AIMS),Kochi,Kerala

As the name suggests this application helps the teenager to choose their career/interests.
