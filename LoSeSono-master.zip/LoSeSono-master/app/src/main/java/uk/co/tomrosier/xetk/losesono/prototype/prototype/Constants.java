package uk.co.tomrosier.xetk.losesono.prototype.prototype;

/**
 * Theses are constants that are changed between different types of build eg production or development.
 */
public class Constants {
    public static final String BASE_URL = "https://46.101.9.11";
    //public static final String BASE_URL = "https://csclp0132.csc.aber.ac.uk:8080";
}
