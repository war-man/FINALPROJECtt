package uk.co.tomrosier.xetk.losesono.prototype.prototype;

/**
 * This is the two effects than can be add when voting on a post or message, made them enums to make them easy to track.
 */
public enum ActionEffect {
    positive,
    negative;
}
