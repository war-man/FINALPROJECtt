package uk.co.tomrosier.xetk.losesono.prototype.prototype;

/**
 * Theses are the different types of votes we can have. either for a message or a comment.
 */
public enum VoteType{
    message,
    comment;
}
