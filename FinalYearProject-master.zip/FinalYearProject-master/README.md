# FinalYearProject
Description:  Smart Android Assistant Application that helps users with their day-to-day life. Final Year Project of the course Software Development(lvl 8)in IT Carlow

# Install Instructions
# Option 1 - Clone Repository and Run App
Prerequisite 
Java installed and jvm set up.
Have Windows, Linux or another operating system installed and working on your machine.

Steps:

1.	Download and install Android Studio → https://developer.android.com/studio
 
2.	Open Android Studio and click “Check out project from Version Control”
 
3.	Select Git and insert URL →  https://github.com/Mark-McCleane/FinalYearProject
 
4.	Wait for updates and downloads to finish. This may take a few minutes
 
5.	Select “Run” in the top toolbar and then select “Run ‘app’ “.
 


 6.	Selected Android connected device(make sure USB debugging and developer options are enabled if required).
	6B. If you do not have android device, click create new virtual device,Select Pixel XL → Next → Oreo(Release) → Choose your AVD Name → Finish

7.	On your virtual device, go to Settings → Apps & Notifications → SAM APP → Permissions.

8. 	Enable all permissions. Enable Calendar for calendar use, Contacts for contacts use such as calls and texts, Location for the directions to function, Microphone for microphone permissions(Always has this enabled) , SMS for messaging, Storage and Telephone for calling and ring function.	
# Option 2 - APK Download

Prerequisite

Have Android device set up and allowed to install APK’s from google drive and google chrome https://www.wikihow.tech/Install-APK-Files-on-Android 

Download APK → https://drive.google.com/file/d/19jXU4NAfkSGDl3GTLw3kHSFDVxp5T0hL/view?usp=sharing

Enable all permissions. Enable Calendar for calendar use, Contacts for contacts use such as calls and texts, Location for the directions to function, Microphone for microphone permissions(Always has this enabled) , SMS for messaging, Storage and Telephone for calling and ring function
