package extra;

import com.assignment.mycalendar.CalendarListActivity;

import android.R;
import android.content.Context;
import android.database.Cursor;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

public class MySimpleCursorAdapter extends SimpleCursorAdapter {
	
	
    public MySimpleCursorAdapter(Context context, int layout, Cursor c, String[] from, int[] to) {
		super(context, layout, c, from, to);
		// TODO Auto-generated constructor stub
	}


	@Override
    public void setViewText(TextView v, String text) {
        if (v.getId() == R.id.text2) { // Make sure it matches your time field
            // You may want to try/catch with NumberFormatException in case `text` is not a numeric value
            text = CalendarListActivity.getDate(Float.parseFloat(text), "dd-MMMM-yyyy");
        }
        v.setText(text);
    }
}