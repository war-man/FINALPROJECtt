//11042712
//Isaac Kingsley Tyson-Seale
package com.assignment.mycalendar.calendardata;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.SQLException;
import android.net.Uri;

public class EntriesProvider extends ContentProvider {

	/** The DAO providing access to the SQLite database */
	private CalendarDAO mDAO;
	/**
	 * UriMatcher used to determine which of the  URI patterns is being
	 */
	private static final UriMatcher mUriMatcher;

	 //Constants used by the Uri
	// The URI matches the URI for a list of entries
	private static final int ENTRIES = 1;

	// The URI matches the URI a single entry
	private static final int ENTRIES_ID = 2;

	static {
		//Create and initialise URI matcher
		// Create a new URI instance
		mUriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
		// Add the list of entries URI
		mUriMatcher.addURI(CalendarEntry.AUTHORITY, "entries", ENTRIES);
		// Add the single entry URI
		mUriMatcher.addURI(CalendarEntry.AUTHORITY, "entries/#", ENTRIES_ID);
	}
	
	@Override
	// Return true shows the Provider loaded
	public boolean onCreate() {
		mDAO = new CalendarDAO(getContext());
		return true;
	}

	@Override
	// Choose the mime type 
	public String getType(Uri uri) {
		//  Match the uri
		switch (mUriMatcher.match(uri)) {
		// All entries URI type
		case ENTRIES:
			// Return the content type
			return CalendarEntry.EntryItem.CONTENT_TYPE;
			// single entry ID type
		case ENTRIES_ID:
			// Return content type
			return CalendarEntry.EntryItem.CONTENT_ITEM_TYPE;
			// unknown URI returns error
		default:
			throw new IllegalArgumentException("URI Unknown" + uri);	
		}
	}
	
	@Override
		//Queries database, returns a cursor result.
	public Cursor query(Uri uri, String[] projection, String selection,
			String[] selectionArgs, String sortOrder) {
		Cursor cursor = null;

		switch (mUriMatcher.match(uri)) {
		case ENTRIES:
			//all entries, call the queryEntries
			cursor = mDAO.queryEntries(projection, selection, selectionArgs,
					sortOrder);
			break;
		case ENTRIES_ID:
			//  single entry
			int entriesId = Integer.parseInt(uri.getPathSegments().get(
					CalendarEntry.EntryItem.ENTRIES_ID_PATH_POSITION));
			// Call by ID
			cursor = mDAO.queryById(entriesId, projection);
			break;
		default:
			// unknown URI returns error
			throw new IllegalArgumentException("URI Unknown" + uri);
		}
		// Configure cursor
		cursor.setNotificationUri(getContext().getContentResolver(), uri);
		// return the retrieved cursor
		return cursor;
	}

	@Override
	public Uri insert(Uri uri, ContentValues values) {
		// Validate the URI. full URI is  needed
		if (mUriMatcher.match(uri) != ENTRIES) {
			throw new IllegalArgumentException("URI Unknown" + uri);
		}
		long rowId = mDAO.insertEntries(values);

		if (rowId > 0) {
			Uri entriesUri = ContentUris.withAppendedId(
					CalendarEntry.EntryItem.CONTENT_ID_URI_BASE, rowId);
			// data change notification
			getContext().getContentResolver().notifyChange(entriesUri, null);
			return entriesUri;
		}
		// If the insert failed, show error
		throw new SQLException("Failed to insert row into " + uri);
	}
	
	@Override
	public int update(Uri uri, ContentValues values, String where,
			String[] whereArgs) {
		int count;
		// update based on the URI pattern
		switch (mUriMatcher.match(uri)) {

		// general updated based on incoming data
		case ENTRIES:

			// Does the update, returns the number of updated rows.
			count = mDAO.updateEntries(values, where, whereArgs); // spelling mistake
			break;

		// If the incoming URI matches a single entry, does the update
			// but modifies the where clause to that particular entry
		case ENTRIES_ID:
			// get the entry ID from URI
			int entriesId = Integer.parseInt(uri.getPathSegments().get(
					CalendarEntry.EntryItem.ENTRIES_ID_PATH_POSITION));
			count = mDAO.updateById(entriesId, values);
			break;
			// unknown URI returns error
		default:
			throw new IllegalArgumentException("URI Unknown" + uri);
		}
		 //and notifies content resolver that the URI has changed
		getContext().getContentResolver().notifyChange(uri, null);

		// Returns the number of updated rows.
		return count;
	}

	@Override
	public int delete(Uri uri, String where, String[] whereArgs) {
		int count;

		// delete based on URI .
		switch (mUriMatcher.match(uri)) {
		// a delete using on the where columns + arguments.
		case ENTRIES:
			count = mDAO.deleteEntry(where, whereArgs);
			break;
		// single ID URI  delete using the ID
		case ENTRIES_ID:
			int entriesId = Integer.parseInt(uri.getPathSegments().get(
					CalendarEntry.EntryItem.ENTRIES_ID_PATH_POSITION));
			count = mDAO.deleteById(entriesId); //
			break;
			// unknown URI returns error
		default:
			throw new IllegalArgumentException("URI Unknown" + uri);
		}
		// uri change notification
		getContext().getContentResolver().notifyChange(uri, null);
		// Returns the number of deleted rows.
		return count;
	}
	
	public DBHelper getDbHelperForTest() {
		return mDAO.getDbHelperForTest();
	}
}
