//11042712
//Isaac Kingsley Tyson-Seale
package com.assignment.mycalendar.calendardata;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

	private static final String DATABASE_NAME = "mycalendar.db";	//Set the name of the database

	private static final int DATABASE_VERSION = 1;
	//if the database doesn't exist, creates it using the values given
    private static final String CALENDAR_TABLE_CREATE =
                "CREATE TABLE " + CalendarEntry.EntryItem.TABLE_NAME + " (" +
                CalendarEntry.EntryItem.COLUMN_NAME_ID + " INTEGER PRIMARY KEY," + 
                CalendarEntry.EntryItem.COLUMN_NAME_LOCATION + " TEXT, " +
                CalendarEntry.EntryItem.COLUMN_NAME_TITLE + " TEXT, " + 
                CalendarEntry.EntryItem.COLUMN_NAME_ENTRY_DATE + " REAL, " +
                CalendarEntry.EntryItem.COLUMN_NAME_END_DATE + " REAL, " +
                CalendarEntry.EntryItem.COLUMN_NAME_ENTRY_TIME + " TEXT, " +
                CalendarEntry.EntryItem.COLUMN_NAME_END_TIME + " TEXT, " +
                CalendarEntry.EntryItem.COLUMN_NAME_START_DATE + " TEXT " +
                ");";
    
    private static final String THEME_TABLE_CREATE =
            "CREATE TABLE " + CalendarEntry.EntryItem.TABLE_NAME + " (" +
            CalendarEntry.EntryItem.COLUMN_NAME_ID + " INTEGER PRIMARY KEY," + //ThemeID 
            		// theme name
            CalendarEntry.EntryItem.COLUMN_NAME_LOCATION + " TEXT, " + //BackgroundColour
            CalendarEntry.EntryItem.COLUMN_NAME_END_DATE + " REAL, " + //normal text colour
            CalendarEntry.EntryItem.COLUMN_NAME_START_DATE + " TEXT " + //today text colour
            //cell bg colour
            //deleteable
            
            
            ");";
    
        
    public DBHelper(Context context) {
    	// If the 2nd parameter is null then the database is held in memory
    	super(context, DATABASE_NAME, null, DATABASE_VERSION);
	}
    
    /**
 		The presence of the 2nd argument causes the in-memory db to be created
     */
    public DBHelper(Context context, boolean testMode) {
    	// If the 2nd parameter is null then the database is held in memory
    	super(context, null, null, DATABASE_VERSION);
	}
    
	@Override
	public void onCreate(SQLiteDatabase database) {
		database.execSQL(CALENDAR_TABLE_CREATE);
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int arg, int arg2) {
			//not used, breaks if deleted
	}

}
