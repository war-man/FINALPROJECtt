//11042712
//Isaac Kingsley Tyson-Seale
package com.assignment.mycalendar.calendardata;

import java.util.HashMap;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.text.TextUtils;
import android.util.Log;

public class CalendarDAO {

	private static final String TAG="DAO";

	private DBHelper mHelper;
	//projection map used to select columns from the database
    private static HashMap<String, String> sEntriesProjection;   
    

    // configure the columns
    static {
        // Creates a new projection map 
    	sEntriesProjection = new HashMap<String, String>();
        // Maps the string to the column name
		Log.i(TAG, "dao2");
		sEntriesProjection.put(CalendarEntry.EntryItem.COLUMN_NAME_ID, CalendarEntry.EntryItem.COLUMN_NAME_ID);     
		sEntriesProjection.put(CalendarEntry.EntryItem.COLUMN_NAME_LOCATION, CalendarEntry.EntryItem.COLUMN_NAME_LOCATION);  
		sEntriesProjection.put(CalendarEntry.EntryItem.COLUMN_NAME_TITLE, CalendarEntry.EntryItem.COLUMN_NAME_TITLE);  
		sEntriesProjection.put(CalendarEntry.EntryItem.COLUMN_NAME_ENTRY_DATE, CalendarEntry.EntryItem.COLUMN_NAME_ENTRY_DATE);
		sEntriesProjection.put(CalendarEntry.EntryItem.COLUMN_NAME_END_DATE, CalendarEntry.EntryItem.COLUMN_NAME_END_DATE);
		sEntriesProjection.put(CalendarEntry.EntryItem.COLUMN_NAME_ENTRY_TIME, CalendarEntry.EntryItem.COLUMN_NAME_ENTRY_TIME);
		sEntriesProjection.put(CalendarEntry.EntryItem.COLUMN_NAME_END_TIME, CalendarEntry.EntryItem.COLUMN_NAME_END_TIME);
		sEntriesProjection.put(CalendarEntry.EntryItem.COLUMN_NAME_START_DATE, CalendarEntry.EntryItem.COLUMN_NAME_START_DATE);
		Log.i(TAG, "dao3");	
    }
    
	public CalendarDAO(Context context) {
	
		mHelper = new DBHelper(context);
		Log.i(TAG, "dao4");
	}
	
	protected CalendarDAO(Context context, boolean testMode) {
		Log.i(TAG, "dao5");
		if(testMode){
			Log.i(TAG, "dao6");
			mHelper = new DBHelper(context, testMode);
			Log.i(TAG, "dao7");
		} else {
			mHelper = new DBHelper(context);
			Log.i(TAG, "dao8");
		}
	}	
	
	//Deletes Entries by  id
	public int deleteById(int id) {
		Log.i(TAG, "dao9");
        String finalWhere =
        		CalendarEntry.EntryItem.COLUMN_NAME_ID +             // The ID column name
        		" = " +                                          // equality test
        		id;
        SQLiteDatabase db = mHelper.getWritableDatabase();
	    // Performs the delete.
	    int count = db.delete(
	        CalendarEntry.EntryItem.TABLE_NAME,  // The database table name.
	        finalWhere,                // The  WHERE clause
	        null                  // The incoming where clause values.
	    );
		return count;
	}
	
	//Deletes Entries as specified
    public int deleteEntry(String where, String[] whereArgs) {
		Log.i(TAG, "dao10");

        // Opens the database object in "write" mode.
        SQLiteDatabase db = mHelper.getWritableDatabase();

        int count = db.delete(
                    CalendarEntry.EntryItem.TABLE_NAME,  // The database table name
                    where,                     // The incoming where clause column names
                    whereArgs                  // The incoming where clause values
                );
        return count;
    }	
	
	public long insertEntries(ContentValues eValues) {

     // If the values map is not null, uses it for the new values.
     if (eValues != null) {
    	 eValues = new ContentValues(eValues);

     } else {
         // else, create a new value map
    	 eValues = new ContentValues();
     }

     // Gets the current system time in milliseconds
     Long now = Long.valueOf(System.currentTimeMillis());
     
     // sets the value to the default value, today.
     if (eValues.containsKey(CalendarEntry.EntryItem.COLUMN_NAME_ENTRY_DATE) == false) {
    	 eValues.put(CalendarEntry.EntryItem.COLUMN_NAME_ENTRY_DATE, now);
     }     

     // sets the value to the default value, today.
     if (eValues.containsKey(CalendarEntry.EntryItem.COLUMN_NAME_END_DATE) == false) {
    	 eValues.put(CalendarEntry.EntryItem.COLUMN_NAME_END_DATE, now);
     }   
     
  
     if (eValues.containsKey(CalendarEntry.EntryItem.COLUMN_NAME_ENTRY_TIME) == false) { 
    	 eValues.put(CalendarEntry.EntryItem.COLUMN_NAME_ENTRY_TIME, "12:00");
     }  
        
     if (eValues.containsKey(CalendarEntry.EntryItem.COLUMN_NAME_END_TIME) == false) { 
    	 eValues.put(CalendarEntry.EntryItem.COLUMN_NAME_END_TIME, "12:01");
     }
     
     if (eValues.containsKey(CalendarEntry.EntryItem.COLUMN_NAME_TITLE) == false) {
    	 eValues.put(CalendarEntry.EntryItem.COLUMN_NAME_TITLE, "<Title>"); 
     }
     
     // Opens the database object in "write" mode.
     SQLiteDatabase database = mHelper.getWritableDatabase();

     // Performs the insert and returns the ID of the new Entries item.
     long rowId = database.insert(
         CalendarEntry.EntryItem.TABLE_NAME,        // The table to insert into.
         CalendarEntry.EntryItem.COLUMN_NAME_TITLE,  //SQLite sets this column value to null if values is empty.
         eValues                          
     );

     if(rowId < 0){
    	 throw new SQLException("Failed to insert Entry(s).");
     }
     return rowId;
	}	
	
	//Queries the database for a single Entry item based on  ID
	public Cursor queryById(int EntriesId, String[] projection)
	{
	       // Constructs a new query builder and sets its table name
	       SQLiteQueryBuilder qb = new SQLiteQueryBuilder();
	       qb.setTables(CalendarEntry.EntryItem.TABLE_NAME);
	       qb.appendWhere(CalendarEntry.EntryItem.COLUMN_NAME_ID +    // the name of the ID column
	    	        "=" +
	    	        EntriesId);
	       return doQuery(qb, projection, null, null, null);		
	}
	
	// General query method for Entries
	public Cursor queryEntries(String[] projection, String selection, String[] selectionArgs, String sortOrder)
	{
	       // Constructs a new query builder and sets its table name
	       SQLiteQueryBuilder qb = new SQLiteQueryBuilder();
	       qb.setTables(CalendarEntry.EntryItem.TABLE_NAME);
	       return doQuery(qb, projection, selection, selectionArgs, sortOrder);
	}
	
	private Cursor doQuery(SQLiteQueryBuilder qb, String[] projection, String selection, String[] selectionArgs, String sortOrder)
	{
	       // Opens database in "read" mode
	       SQLiteDatabase db = mHelper.getReadableDatabase();
	       
	       qb.setProjectionMap(sEntriesProjection);       
	       String orderBy;
	       //uses default sort order
	       if (TextUtils.isEmpty(sortOrder)) {
	           orderBy = CalendarEntry.EntryItem.DEFAULT_SORT_ORDER;
	       } else {
	           // else use specified sort order
	           orderBy = sortOrder;
	       }
	       
	       Log.i(TAG, "doQuery - Projection = " + projection);
	       
	       Cursor c = qb.query(
	           db,            // database
	           projection,    // columns to return
	           selection,     // columns for the where
	           selectionArgs, // values for the where
	           null,          // dont group the rows
	           null,          // dont filter by row groups
	           orderBy        //  sort order
	       );
	       return c;
	}
	

		//Updates Entry item specified by EntriesId parameter. If ID specified is in values parameter it will be ignored.
    public int updateById( int EntriesId, ContentValues values) {
        SQLiteDatabase db = mHelper.getWritableDatabase();
        int count;
        		String where =
        		CalendarEntry.EntryItem.COLUMN_NAME_ID +   // ID column
        		" = " +  EntriesId;                     // check equality

        // Does  update, returns number of rows updated.
        count = db.update(
        CalendarEntry.EntryItem.TABLE_NAME, // database table.
            values,                   // column names and new values.
            where,               //  WHERE clause
            null                 // where clause column values to select, null if the values are in the where argument.
        );
        // Returns number of updated rows.
        return count;
    }
    
    // Updates all Entries matching where and whereArgs
    public int updateEntries(ContentValues cValues, String where, String[] whereArgs) {
        SQLiteDatabase db = mHelper.getWritableDatabase();
        int counter;
        // Updates
        counter = db.update(CalendarEntry.EntryItem.TABLE_NAME, cValues, where, whereArgs);
        //returns number of rows updated.
        return counter;
    }	

    // Used by test classes to access the database helper   
    DBHelper getDbHelperForTest() {
        return mHelper;
    }     
}
