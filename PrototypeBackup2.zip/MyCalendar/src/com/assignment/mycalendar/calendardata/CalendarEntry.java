//11042712
//Isaac Kingsley Tyson-Seale
package com.assignment.mycalendar.calendardata;

import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.provider.BaseColumns;

public final class CalendarEntry implements java.io.Serializable{
	
	private static final long serialVersionUID = 1L;
	private static final String TAG = "CalendarEntry";

	public static final String AUTHORITY = "com.assignment.mycalendar.Entries";
	
	public String location;
	public String title;
	public float entryDate;	
	public String entryTime;
	public String endTime;
	public long endDate; 
	public String startDate;

	//Create instance from a ContentValues object
	public CalendarEntry(ContentValues cValues){
		location = cValues.getAsString(CalendarEntry.EntryItem.COLUMN_NAME_LOCATION );
		title = cValues.getAsString(CalendarEntry.EntryItem.COLUMN_NAME_TITLE);
		entryDate = cValues.getAsLong(CalendarEntry.EntryItem.COLUMN_NAME_ENTRY_DATE);
		entryTime = cValues.getAsString(CalendarEntry.EntryItem.COLUMN_NAME_ENTRY_TIME);
		endTime = cValues.getAsString(CalendarEntry.EntryItem.COLUMN_NAME_END_TIME);
		entryDate = cValues.getAsLong(CalendarEntry.EntryItem.COLUMN_NAME_END_DATE);
		startDate = cValues.getAsString(CalendarEntry.EntryItem.COLUMN_NAME_START_DATE);
	}
	
	public CalendarEntry(String location, String title, float date, String eTime, String time, long eDate, String sDate ){
		this.location = location;
		this.title = title;
		entryDate = date;
		entryTime = time;
		endTime = eTime;
		endDate = eDate;
		startDate = sDate;
	}	
	
	// Returns a ContentValues instance
    public ContentValues getContents() {
        // Gets a new ContentValues object
        ContentValues v = new ContentValues();

        // Adds map entries for the user-controlled fields in the map
        v.put(CalendarEntry.EntryItem.COLUMN_NAME_LOCATION, location);
        v.put(CalendarEntry.EntryItem.COLUMN_NAME_TITLE, title);
        v.put(CalendarEntry.EntryItem.COLUMN_NAME_ENTRY_DATE, entryDate);
        v.put(CalendarEntry.EntryItem.COLUMN_NAME_ENTRY_TIME, entryTime);
        v.put(CalendarEntry.EntryItem.COLUMN_NAME_END_TIME, endTime);
        v.put(CalendarEntry.EntryItem.COLUMN_NAME_END_DATE, endDate);
        v.put(CalendarEntry.EntryItem.COLUMN_NAME_START_DATE, startDate);
        return v;
    }    	
	
    //define the database structure
	public static final class EntryItem implements BaseColumns {
		
        private EntryItem() {}
        //The table name
        public static final String TABLE_NAME = "entries";

        //URI definitions
        private static final String SCHEME = "content://";

        //Path parts for the URIs
        //Path part for the entries URI
        private static final String PATH_ENTRIES = "/entries";


        //Path part for the entries ID URI
        private static final String PATH_ENTRIES_ID = "/entries/";

        public static final int ENTRIES_ID_PATH_POSITION = 1;

        // The content:// style URL for this table
        public static final Uri CONTENT_URI =  Uri.parse(SCHEME + AUTHORITY + PATH_ENTRIES);

        //The content URI base for a single entry.

        public static final Uri CONTENT_ID_URI_BASE
            = Uri.parse(SCHEME + AUTHORITY + PATH_ENTRIES_ID);        
        
        //The default sort order
        public static final String DEFAULT_SORT_ORDER = CalendarEntry.EntryItem.COLUMN_NAME_ENTRY_DATE + " ASC";   
        
        // for when you expect the Cursor to contain 0..x items
        public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd.mycalendar.entries";
        // for when you expect the Cursor to contain 1 item
        public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/vnd.mycalendar.entries";
        
        //Column definitions
        public static final String COLUMN_NAME_LOCATION = "location";
        public static final String COLUMN_NAME_TITLE = "title";
        
        //Column name for the timestamp and date
        public static final String COLUMN_NAME_ENTRY_DATE = "_date";       
        public static final String COLUMN_NAME_ENTRY_TIME = "_time"; 
        public static final String COLUMN_NAME_END_TIME = "_etime";
        public static final String COLUMN_NAME_END_DATE = "_edate";
        public static final String COLUMN_NAME_START_DATE = "_sdate";
        
        public static final String COLUMN_NAME_ID = BaseColumns._ID;
        
        //all the columns required to populate an entry
        public static final String[] FULL_PROJECTION = {
        	COLUMN_NAME_LOCATION,
                COLUMN_NAME_TITLE,
                COLUMN_NAME_ENTRY_DATE,
                COLUMN_NAME_ENTRY_TIME,
                COLUMN_NAME_END_TIME,
                COLUMN_NAME_END_DATE,
                COLUMN_NAME_START_DATE
            };        
        
        public static final String[] LIST_PROJECTION =
            new String[] {
                CalendarEntry.EntryItem._ID,
                CalendarEntry.EntryItem.COLUMN_NAME_TITLE,
                CalendarEntry.EntryItem.COLUMN_NAME_ENTRY_DATE,
                CalendarEntry.EntryItem.COLUMN_NAME_START_DATE
        };            
	}

	public static final class Helper {
			// Converts a cursor into an array of entries 
		public static final CalendarEntry[] getEntries(Cursor mCursor){
			CalendarEntry[] entries = null;
			int rows = mCursor.getCount();
			if(rows > 0){
				entries = new CalendarEntry[rows];
				int i=0;
				while(mCursor.moveToNext()){
					entries[i++] = new CalendarEntry( mCursor.getString(0), mCursor.getString(1), mCursor.getFloat(2), mCursor.getString(3), mCursor.getString(4), mCursor.getLong(5), mCursor.getString(6));
													//description,          title,                Date,              Time				 eTime
				}
			}
			return entries;
		}				
	}	
}
