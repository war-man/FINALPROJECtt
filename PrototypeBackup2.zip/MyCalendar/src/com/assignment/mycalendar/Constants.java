//11042712
//Isaac Kingsley Tyson-Seale
package com.assignment.mycalendar;

public class Constants {
	//Set the constant variables
	private Constants(){}
		
	/** Preferences */
	public static final String CALENDAR_ID = "cal_id";
	public static final long CALENDAR_ITEM_UNDEFINED = -1;
	
	public static final String CALENDAR_TITLE = "cal_title";
	
	protected static final int DATE_DIALOG_ID = 100;
	protected static final int TIME_DIALOG_ID = 200;	
	protected static final int ENDDATE_DIALOG_ID = 300;
	protected static final int ENDTIME_DIALOG_ID = 400;
	
	protected static final String[] months = { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };
	protected static final int[] daysOfMonth = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
	protected static final String[] weekdays = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };

	
}
