package com.assignment.mycalendar;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import android.annotation.TargetApi;
import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;
import android.content.Intent;

import com.assignment.mycalendar.R;
import com.assignment.mycalendar.calendardata.CalendarEntry;

@TargetApi(16)
public class MyCalendarActivity extends Activity implements OnClickListener {
	private static final String tag = "MyCalendarActivity";

	private TextView currentMonth;
	private Button selectedDayMonthYearButton;
	private GridView calendarView;
	private GridCellAdapter gCAdapter;
	private Calendar _calendar;
	
	private String selectedDate = "01-January-2015"; //default to 1st jan 2015 to avoid crashes.
	
	private int month, year;

	private final DateFormat dateFormatter = new DateFormat();
	private static final String dateTemplate = "MMMM yyyy";

	/** Called when the activity is first created. */

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.my_calendar_view);

		getActionBar().setHomeButtonEnabled(false);
		getActionBar().setDisplayHomeAsUpEnabled(false);
		getActionBar().setDisplayShowTitleEnabled(false);

		
		
		// Create an array adapter to populate dropdownlist 
	    ArrayAdapter<String> adapter2 =new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, Constants.months);

	    /** Enabling dropdown list navigation for the action bar */
	    getActionBar().setNavigationMode(ActionBar.NAVIGATION_MODE_LIST);

	    /** Defining Navigation listener */
	    ActionBar.OnNavigationListener navigationListener=new ActionBar.OnNavigationListener() {

	        @Override
	        public boolean onNavigationItemSelected(int itemPosition, long itemId) {
	        	if (Constants.months[itemPosition].equals("January")) {
	                System.out.println("January Selected");
	                changeMonth(1, year);
	            }
	        	else if (Constants.months[itemPosition].equals("February")) {
	        		System.out.println("February Selected");
	        		changeMonth(2, year);
	            }
	        	else if (Constants.months[itemPosition].equals("March")) {
	        		System.out.println("March Selected");
	        		changeMonth(3, year);
	            }
	        	else if (Constants.months[itemPosition].equals("April")) {
	        		System.out.println("April Selected");
	        		changeMonth(4, year);
	            }
	        	else if (Constants.months[itemPosition].equals("May")) {
	        		System.out.println("April Selected");
	        		changeMonth(5, year);
	            }
	        	else if (Constants.months[itemPosition].equals("June")) {
	        		System.out.println("April Selected");
	        		changeMonth(6, year);
	            }
	        	else if (Constants.months[itemPosition].equals("July")) {
	        		System.out.println("April Selected");
	        		changeMonth(7, year);
	            }
	        	else if (Constants.months[itemPosition].equals("August")) {
	        		System.out.println("April Selected");
	        		changeMonth(8, year);
	            }
	        	else if (Constants.months[itemPosition].equals("September")) {
	        		System.out.println("April Selected");
	        		changeMonth(9, year);
	            }
	        	else if (Constants.months[itemPosition].equals("October")) {
	        		System.out.println("April Selected");
	        		changeMonth(10, year);
	            }
	        	else if (Constants.months[itemPosition].equals("November")) {
	        		System.out.println("April Selected");
	        		changeMonth(11, year);
	            }
	        	else if (Constants.months[itemPosition].equals("December")) {
	        		System.out.println("April Selected");
	        		changeMonth(12, year);
	            }
	            return false;
	        }
	    };

	    // Setting dropdown items and item navigation listener for the actionbar 
	    getActionBar().setListNavigationCallbacks(adapter2, navigationListener);
	    		
		_calendar = Calendar.getInstance(Locale.getDefault());
		month = _calendar.get(Calendar.MONTH) + 1;
		year = _calendar.get(Calendar.YEAR);
		Log.d(tag, "Calendar Instance:= " + "Month: " + month + " " + "Year: " + year);

		selectedDayMonthYearButton = (Button) this.findViewById(R.id.selectedDayMonthYear);
		selectedDayMonthYearButton.setText("Selected: 01-January " + year);
		
		currentMonth = (TextView) this.findViewById(R.id.currentMonth);
		currentMonth.setText(DateFormat.format(dateTemplate, _calendar.getTime()));

		calendarView = (GridView) this.findViewById(R.id.calendar);

		// Initialised
		gCAdapter = new GridCellAdapter(getApplicationContext(), R.id.calendar_day_gridcell, month, year);
		gCAdapter.notifyDataSetChanged();
		calendarView.setAdapter(gCAdapter);
			
		Intent mIntent = getIntent();
		
        if (mIntent.getData() == null) {
        	mIntent.setData(CalendarEntry.EntryItem.CONTENT_URI);
        }  
		Log.i(tag, "1");
        
	}
	
	/**
	 * 
	 * @param month
	 * @param year
	 */
    
	@Override
	public boolean onCreateOptionsMenu(Menu oMenu) {
		MenuInflater mInflater = getMenuInflater();
		mInflater.inflate(R.menu.main_activity_menu, oMenu);
		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem mItem) {
		// add options to the Menu
		switch (mItem.getItemId()) {
	    case R.id.menu_add:
	    	addCalendarEntry();
			return true;	
	    case R.id.menu_list:
	    listView();
			return true;
	    case R.id.action_year_minus:
	    year --;
	    changeMonth(month, year);
			return true;
	    case R.id.action_plus:
	    year ++;
	    changeMonth(month, year);
			return true; 	
		default:
			return super.onOptionsItemSelected(mItem);
		}
	}
	
	private void addCalendarEntry() {	
	  	Intent mIntent = new Intent(this, CalendarEntryActivity.class);
	  	mIntent.setData(getIntent().getData()); 
	  	mIntent.putExtra(Constants.CALENDAR_ID, Constants.CALENDAR_ITEM_UNDEFINED);		
	  	startActivity(mIntent);
	}
	
	private void listView() {	
	  Intent mIntent = new Intent(this, CalendarListActivity.class);
	 // Intent mIntent = new Intent(this, Test.class);
	  	startActivity(mIntent);  
	}
	
	private void setGridCellAdapterToDate(int month, int year) {
		gCAdapter = new GridCellAdapter(getApplicationContext(), R.id.calendar_day_gridcell, month, year); 
		_calendar.set(year, month - 1, _calendar.get(Calendar.DAY_OF_MONTH));
		currentMonth.setText(DateFormat.format(dateTemplate, _calendar.getTime()));
		gCAdapter.notifyDataSetChanged();
		calendarView.setAdapter(gCAdapter);
	}

	
	public void changeMonth(int monthNo, int mYear){
		month = monthNo;
		year = mYear;
		setGridCellAdapterToDate(month, year);
		Log.d(tag, "Setting Month in GridCellAdapter: " + "Month: " + month + " Year: " + year);
	}
	
	@Override
	public void onClick(View v) {
		
	}

	@Override
	public void onDestroy() {
		Log.d(tag, "Destroying View ...");
		super.onDestroy();
	}

	// Inner Class
	public class GridCellAdapter extends BaseAdapter implements OnClickListener {

		private static final String tag = "GridCellAdapter";
		private final Context _context;
		private final List<String> list;
		private static final int DAY_OFFSET = 1;

		private int daysInMonth;
		private int currentDayOfMonth;
		private int currentWeekDay;
		private Button gridcell;
		private TextView num_events_per_day;
		private final HashMap<String, Integer> eventsPerMonthMap;
		private final SimpleDateFormat dateFormatter = new SimpleDateFormat("dd-MMM-yyyy", Locale.UK);

		// Days in Current Month
		public GridCellAdapter(Context context, int textViewResourceId, int month, int year) {
			super();
			this._context = context;
			this.list = new ArrayList<String>();
			Log.d(tag, "==> Passed in Date FOR Month: " + month + " " + "Year: " + year);
			Calendar calendar = Calendar.getInstance();
			setCurrentDayOfMonth(calendar.get(Calendar.DAY_OF_MONTH));
			setCurrentWeekDay(calendar.get(Calendar.DAY_OF_WEEK));
			Log.d(tag, "New Calendar:= " + calendar.getTime().toString());
			Log.d(tag, "CurrentDayOfWeek :" + getCurrentWeekDay());
			Log.d(tag, "CurrentDayOfMonth :" + getCurrentDayOfMonth());

			// Print Month
			printMonth(month, year);

			// Find Number of Events
			eventsPerMonthMap = findNumberOfEventsPerMonth(year, month);
		}

		private String getMonthAsString(int i) {
			return Constants.months[i];
		}

		private String getWeekDayAsString(int i) {
			return Constants.weekdays[i];
		}

		private int getNumberOfDaysOfMonth(int i) {
			return Constants.daysOfMonth[i];
		}

		public String getItem(int position) {
			return list.get(position);
		}

		@Override
		public int getCount() {
			return list.size();
		}

		/**
		 * Prints Month
		 * 
		 * @param mm
		 * @param yy
		 */
		private void printMonth(int mm, int yy) {
			Log.d(tag, "==> printMonth: mm: " + mm + " " + "yy: " + yy);
			int trailingSpaces = 0;
			int daysInPrevMonth = 0;
			int prevMonth = 0;
			int prevYear = 0;
			int nextMonth = 0;
			int nextYear = 0;

			int currentMonth = mm - 1;
			String currentMonthName = getMonthAsString(currentMonth);
			daysInMonth = getNumberOfDaysOfMonth(currentMonth);

			Log.d(tag, "Current Month: " + " " + currentMonthName + " having " + daysInMonth + " days.");

			GregorianCalendar cal = new GregorianCalendar(yy, currentMonth, 1);
			Log.d(tag, "Gregorian Calendar:= " + cal.getTime().toString());
			
			if (currentMonth == 11) {
				prevMonth = currentMonth - 1;
				daysInPrevMonth = getNumberOfDaysOfMonth(prevMonth);
				nextMonth = 0;
				prevYear = yy;
				nextYear = yy + 1;
				Log.d(tag, "*->PrevYear: " + prevYear + " PrevMonth:" + prevMonth + " NextMonth: " + nextMonth + " NextYear: " + nextYear);
			} else if (currentMonth == 0) {
				prevMonth = 11;
				prevYear = yy - 1;
				nextYear = yy;
				daysInPrevMonth = getNumberOfDaysOfMonth(prevMonth);
				nextMonth = 1;
				Log.d(tag, "**--> PrevYear: " + prevYear + " PrevMonth:" + prevMonth + " NextMonth: " + nextMonth + " NextYear: " + nextYear);
			} else {
				prevMonth = currentMonth - 1;
				nextMonth = currentMonth + 1;
				nextYear = yy;
				prevYear = yy;
				daysInPrevMonth = getNumberOfDaysOfMonth(prevMonth);
				Log.d(tag, "***---> PrevYear: " + prevYear + " PrevMonth:" + prevMonth + " NextMonth: " + nextMonth + " NextYear: " + nextYear);
			}

			int currentWeekDay = cal.get(Calendar.DAY_OF_WEEK) - 1;
			trailingSpaces = currentWeekDay;

			Log.d(tag, "Week Day:" + currentWeekDay + " is " + getWeekDayAsString(currentWeekDay));
			Log.d(tag, "No. Trailing space to Add: " + trailingSpaces);
			Log.d(tag, "No. of Days in Previous Month: " + daysInPrevMonth);

			if (cal.isLeapYear(cal.get(Calendar.YEAR)))
				if (mm == 2) 
					++daysInMonth;
				else if (mm == 3)
					++daysInPrevMonth;

			// Trailing Month days
			for (int i = 0; i < trailingSpaces; i++) {
				Log.d(tag,
						"PREV MONTH:= "
								+ prevMonth
								+ " => "
								+ getMonthAsString(prevMonth)
								+ " "
								+ String.valueOf((daysInPrevMonth
								- trailingSpaces + DAY_OFFSET)
								+ i));
				list.add(String
						.valueOf((daysInPrevMonth - trailingSpaces + DAY_OFFSET)
								+ i)
						+ "-GREY"
						+ "-"
						+ getMonthAsString(prevMonth)
						+ "-"
						+ prevYear);
			}

			// Current Month Days
			for (int i = 1; i <= daysInMonth; i++) {
				Log.d(currentMonthName, String.valueOf(i) + " " + getMonthAsString(currentMonth) + " " + yy);
				if (i == getCurrentDayOfMonth()) {
					list.add(String.valueOf(i) + "-BLUE" + "-" + getMonthAsString(currentMonth) + "-" + yy);
				} else {
					list.add(String.valueOf(i) + "-WHITE" + "-" + getMonthAsString(currentMonth) + "-" + yy);
				}
			}
			
			// Leading Month days
			for (int i = 0; i < list.size() % 7; i++) {
				Log.d(tag, "NEXT MONTH:= " + getMonthAsString(nextMonth));
				list.add(String.valueOf(i + 1) + "-GREY" + "-" + getMonthAsString(nextMonth) + "-" + nextYear);
			}
		}

		/**
		 * NOTE: YOU NEED TO IMPLEMENT THIS PART Given the YEAR, MONTH, retrieve
		 * ALL entries from a SQLite database for that month. Iterate over the
		 * List of All entries, and get the dateCreated, which is converted into
		 * day.
		 * 
		 * @param year
		 * @param month
		 * @return
		 */
		private HashMap<String, Integer> findNumberOfEventsPerMonth(int year, int month) {
			HashMap<String, Integer> map = new HashMap<String, Integer>();

			return map;
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View row = convertView;
			if (row == null) {
				LayoutInflater inflater = (LayoutInflater) _context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				row = inflater.inflate(R.layout.screen_gridcell, parent, false);
			}

			// Get a reference to the Day gridcell
			gridcell = (Button) row.findViewById(R.id.calendar_day_gridcell);
			gridcell.setOnClickListener(this);

			// ACCOUNT FOR SPACING

			Log.d(tag, "Current Day: " + getCurrentDayOfMonth());
			String[] day_color = list.get(position).split("-");
			String theday = day_color[0];
			String themonth = day_color[2];
			String theyear = day_color[3];
			if ((!eventsPerMonthMap.isEmpty()) && (eventsPerMonthMap != null)) {
				if (eventsPerMonthMap.containsKey(theday)) {
					num_events_per_day = (TextView) row.findViewById(R.id.num_events_per_day);
					Integer numEvents = (Integer) eventsPerMonthMap.get(theday);
					num_events_per_day.setText(numEvents.toString());
				}
			}

			// Set the Day GridCell
			int checkDay = Integer.parseInt(theday);
			if (checkDay < 10) {
				theday = 0 +theday;
				}
			
			gridcell.setText(theday);
			gridcell.setTag(theday + "-" + themonth + "-" + theyear);
			Log.d(tag, "Setting GridCell " + theday + "-" + themonth + "-" + theyear);

			if (day_color[1].equals("GREY")) {
				gridcell.setTextColor(getResources().getColor(R.color.lightgray));
			}
			if (day_color[1].equals("WHITE")) {
				gridcell.setTextColor(getResources().getColor(R.color.black));
			}
			if (day_color[1].equals("BLUE")) {gridcell.setTextColor(getResources().getColor(R.color.navy));
			}
			return row;
		}

		@Override
		public void onClick(View view) {
			//gridcell.isPressed();
			//gridcell.setTextColor(getResources().getColor(R.color.navy));
			String date_month_year = (String) view.getTag();
			selectedDayMonthYearButton.setText("Selected: " + date_month_year);
			Log.e("Selected date", date_month_year);
			selectedDate = date_month_year;
			
			 Intent mIntent1 = new Intent(MyCalendarActivity.this, DayListActivity.class);
			 mIntent1.putExtra("datePassed", selectedDate); //pass the selected date to the day view
			 startActivity(mIntent1);
			try {
				Date parsedDate = dateFormatter.parse(date_month_year);
				Log.d(tag, "Parsed Date: " + parsedDate.toString());

			} catch (ParseException e) {
				e.printStackTrace();
			}
		}

		public int getCurrentDayOfMonth() {
			return currentDayOfMonth;
		}

		private void setCurrentDayOfMonth(int currentDayOfMonth) {
			this.currentDayOfMonth = currentDayOfMonth;
		}

		public void setCurrentWeekDay(int currentWeekDay) {
			this.currentWeekDay = currentWeekDay;
		}

		public int getCurrentWeekDay() {
			return currentWeekDay;
		}
	}	
}

