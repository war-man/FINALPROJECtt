//11042712
//Isaac Kingsley Tyson-Seale
package com.assignment.mycalendar;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.text.InputType;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.assignment.mycalendar.R;
import com.assignment.mycalendar.calendardata.CalendarEntry;


public class CalendarEntryActivity extends Activity {
	
private static final String TAG = "CalendarEntryActivity";

	private Button mSaveButton;
	private TextView mLocation;
	private TextView mTitle;
	private TextView mStartTimeDisplay;
	private TextView mStartDateDisplay;
	private TextView mTimeEnd;
	private TextView mDateEnd;
	
	
	///variables used for time and date
	private int mYear, mHour, mMinute, mMonth, mDay; 
	private int eYear, eMonth, eDay, eHour, eMinute; 
	
	private long mEntryId;
	private Uri mUri;
	private Cursor mCursor;	
	private CheckBox checkBox_alarm;
	private Toast toast;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		Log.i(TAG, "onCreate");
		setContentView(R.layout.calendar_entry);
		
		// Set up references to view items.
				checkBox_alarm = (CheckBox) findViewById(R.id.checkBox_alarm);
				mSaveButton = (Button) findViewById(R.id.btn_save);
				mStartTimeDisplay = (TextView) findViewById(R.id.tf_StartTime);
				mStartDateDisplay = (TextView) findViewById(R.id.tf_StartDate);
				mLocation = (EditText) findViewById(R.id.tf_location); 
				mTitle = (TextView) findViewById(R.id.tf_title);
				mTimeEnd = (TextView) findViewById(R.id.tf_EndTime);
				mDateEnd = (TextView) findViewById(R.id.tf_EndDate);
				
				mStartTimeDisplay.setInputType(InputType.TYPE_NULL);
				mTimeEnd.setInputType(InputType.TYPE_NULL);
				mStartDateDisplay.setInputType(InputType.TYPE_NULL);
				mDateEnd.setInputType(InputType.TYPE_NULL);
				

					
				// Call local method configureCursorForActivity()
				configureCursor();
				//add click listener to save button
				mSaveButton.setOnClickListener(new View.OnClickListener() {
					public void onClick(View v) {
						if (checkDate() == true && checkTime() == true){
							//save the data
							Intent resulti = new Intent();
							Log.i(TAG, "oCv1");
							resulti.putExtra(Constants.CALENDAR_TITLE, mTitle.getText().toString());
							Log.i(TAG, "oCv2");
							setResult(Activity.RESULT_OK, resulti); 
							Log.i(TAG, "oCv3");
							finish();
							Log.i(TAG, "oCv4");
						} else {
							CharSequence text = "End time and Date cannot be set before the start time and date.";
							Toast.makeText(getApplicationContext(), text, Toast.LENGTH_SHORT).show();
						}

					}
				});
				
				//add click listener to text views for Time and date pickers
				mStartDateDisplay.setOnClickListener(new DateClickListener());
				mStartTimeDisplay.setOnClickListener(new TimeClickListener());
				
				mDateEnd.setOnClickListener(new eDateClickListener());
				mTimeEnd.setOnClickListener(new eTimeClickListener());
				Log.i(TAG, "oCv5");
			}
	// add a click listener to the date entry field
		private class DateClickListener implements View.OnClickListener {
			@SuppressWarnings("deprecation")
			public void onClick(View v) {
			showDialog(Constants.DATE_DIALOG_ID);
			}
		};	
		// add a click listener to the time entry field
		private class TimeClickListener implements View.OnClickListener {
			@SuppressWarnings("deprecation")
			public void onClick(View v) {
			showDialog(Constants.TIME_DIALOG_ID);
			}
		};	
		
		private class eDateClickListener implements View.OnClickListener {
			@SuppressWarnings("deprecation")
			public void onClick(View v) {
			showDialog(Constants.ENDDATE_DIALOG_ID);
			}
		};	
		// add a click listener to the time entry field
		private class eTimeClickListener implements View.OnClickListener {
			@SuppressWarnings("deprecation")
			public void onClick(View v) {
			showDialog(Constants.ENDTIME_DIALOG_ID);
			}
		};	
		
		@Override
		public boolean onCreateOptionsMenu(Menu oMenu) {
			MenuInflater mInflater = getMenuInflater();
			mInflater.inflate(R.menu.calendar_view_option, oMenu);
			return true;
		}
		
	@SuppressWarnings("deprecation")
	private void configureCursor() {
		// Get the launching intent from the Activity
		Intent launchIntent = getIntent();
		Log.i(TAG, "cursor Config 1");
		// Get the ID of the entry to be edited 
		// Constants.CALENDAR_ITEM_UNDEFINED means the ID was empty so create a new entry)
		mEntryId = launchIntent.getLongExtra(Constants.CALENDAR_ID, Constants.CALENDAR_ITEM_UNDEFINED);
		Log.i(TAG, "cursor Config 2");
		if (Constants.CALENDAR_ITEM_UNDEFINED == mEntryId) {
			Log.i(TAG, "cursor Config 3");
			// As the ID was set to -1, create a new entry 
			// Insert a new  item into the database
			mUri = getContentResolver().insert(launchIntent.getData(), null);
			Log.i(TAG, "cursor Config 4");
			// Get the id of the new entry we made from the uri
			mEntryId = ContentUris.parseId(mUri);
			Log.i(TAG, "cursor Config 5");
			//format the time
			updateTimeDisplay();
		}

		// Build the URI for the Content Provider
		mUri = ContentUris.withAppendedId(launchIntent.getData(), mEntryId);
		Log.i(TAG, "cf6");
		
		// Load a cursor 
		mCursor = managedQuery(mUri,
				CalendarEntry.EntryItem.FULL_PROJECTION, // Projection containing all entry items
				null, //"where" clause selection criteria, null
				null, //"where" clause selection values, null
				null // Use the default sort order
			
		);
		Log.i(TAG, "cf7");	
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		Log.i(TAG, "onPause");
		// checks that the query didn't fail
		if (mCursor != null && checkDate() == true & checkTime() == true) {
			// Call the saveEntryItem method
				saveEntry();
		}	
	}

	private void saveEntry() {
		ContentValues values = new ContentValues();
		
			// Add map entries for user-controlled fields
			// and values from the view
			values.put(CalendarEntry.EntryItem.COLUMN_NAME_TITLE, mTitle.getText().toString());
			values.put(CalendarEntry.EntryItem.COLUMN_NAME_LOCATION, mLocation.getText().toString());
			values.put(CalendarEntry.EntryItem.COLUMN_NAME_ENTRY_DATE, saveGetDateInMillis());
			values.put(CalendarEntry.EntryItem.COLUMN_NAME_ENTRY_TIME, mStartTimeDisplay.getText().toString());
			values.put(CalendarEntry.EntryItem.COLUMN_NAME_END_TIME, mTimeEnd.getText().toString());
			values.put(CalendarEntry.EntryItem.COLUMN_NAME_END_DATE, saveEndDateInMillis());
			values.put(CalendarEntry.EntryItem.COLUMN_NAME_START_DATE, getDateString());
			
			if (checkBox_alarm.isChecked()) {
				createAlarm();
			} else  {
				CharSequence text = "Alarm not set for Event.";
				Toast.makeText(getApplicationContext(), text, Toast.LENGTH_SHORT).show();
			}

			// Provide a URI
			// Call the update method
			getContentResolver().update(mUri, values, null, null);

	}
	
	@Override
	protected void onResume() {
		super.onResume();
		Log.i(TAG, "on Resume");
		// Call method load Entries
		loadEntries();
		Log.i(TAG, "Entries Loaded");
	}

	private void loadEntries() {
	
		if (mCursor != null) {
			Log.i(TAG, "Load Entries 1");
			// Re-query in case something changed while paused
			mCursor.requery();
			Log.i(TAG, "Load Entries 2");
			if (mCursor.moveToFirst()) {
				Log.i(TAG, "Load Entries 3");
				
				// populate the text fields from retrieived data
				mLocation.setText(mCursor.getString(0));
				mTitle.setText(mCursor.getString(1));
				loadGetDateInMillis(mCursor.getLong(2));
				mStartTimeDisplay.setText(mCursor.getString(3));
				mTimeEnd.setText(mCursor.getString(4));
				loadEndDateInMillis(mCursor.getLong(5));
				updateEndtDateDisplay();
				updateDateDisplay();
				Log.i(TAG, "Load Entries 4");
			}
		}
	}	

	@Override
	protected void onStart() {
		super.onStart();
		Log.i(TAG, "on Start");
	}
	@Override
	protected void onStop() {
		super.onStop();
		Log.i(TAG, "on Stop");
	}
	@Override
	protected void onDestroy() {
		super.onDestroy();
		Log.i(TAG, "on Destroy");
	}		
	//Method called for creation of the time and date dialog boxes
	@Override	
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		//gets the date Dialog ID set in const
		case Constants.DATE_DIALOG_ID:
			return new DatePickerDialog(this, mDateSetListener, mYear, mMonth, mDay);
		case Constants.TIME_DIALOG_ID:
            return new TimePickerDialog(this, mTimeSetListener, mHour, mMinute, false);
		case Constants.ENDDATE_DIALOG_ID:
			return new DatePickerDialog(this, mEndDateSetListener, eYear, eMonth, eDay);
		case Constants.ENDTIME_DIALOG_ID:
            return new TimePickerDialog(this, mEndTimeSetListener, eHour, eMinute, false);	
		}
		return null;
	}	

	//received when the user "sets" the date in the dialog
	private DatePickerDialog.OnDateSetListener mDateSetListener = new DatePickerDialog.OnDateSetListener() {
		public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
			mYear = year;
			mMonth = monthOfYear;
			mDay = dayOfMonth;
			updateDateDisplay();
			
		}
	};	
	
	private DatePickerDialog.OnDateSetListener mEndDateSetListener = new DatePickerDialog.OnDateSetListener() {
		public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
			eYear = year;
			eMonth = monthOfYear;
			eDay = dayOfMonth;
			updateEndtDateDisplay();
		}
	};	
	
	//Gets the current date in milliseconds when saving
	private float saveGetDateInMillis() {
		Calendar c= Calendar.getInstance();
		SimpleDateFormat format1 = new SimpleDateFormat("dd-MMMM-yyyy", Locale.UK);

		c.set(mYear, mMonth, mDay);
		String formatted = format1.format(c.getTime());
		System.out.println(formatted);
		
		float date = c.getTimeInMillis();
		
		String str=String.valueOf(date);
		Log.i(TAG, "date in millis = " + str);
		return date;

	}	
	
	private String getDateString() {
		Calendar c= Calendar.getInstance();
		SimpleDateFormat format1 = new SimpleDateFormat("dd-MMMM-yyyy", Locale.UK);

		c.set(mYear, mMonth, mDay);
		String formatted = format1.format(c.getTime());
		System.out.println(formatted);
		
		String date = formatted;
		return date;

	}	
	
	//Gets the current date in milliseconds when saving
	private long saveEndDateInMillis() {
		Calendar b= Calendar.getInstance();
		b.set(eYear, eMonth, eDay);
		long date = b.getTimeInMillis();
		return date;
	}	
	
	//Populates the mYear, mMonth and mDay fields from the supplied time in milliseconds when entry retrieved
	private void loadGetDateInMillis(long dateTime) {
		final Calendar c = Calendar.getInstance();
		c.setTimeInMillis(dateTime);
		mYear = c.get(Calendar.YEAR);
		mMonth = c.get(Calendar.MONTH);
		mDay = c.get(Calendar.DAY_OF_MONTH);
		
	}	
	
	private void loadEndDateInMillis(long dateTime) {
		final Calendar c = Calendar.getInstance();
		c.setTimeInMillis(dateTime);
		eYear = c.get(Calendar.YEAR);
		eMonth = c.get(Calendar.MONTH);
		eDay = c.get(Calendar.DAY_OF_MONTH);
	}

	//Formats the date so it shows as MM-dd-yyyy in the text box
	private void updateDateDisplay() {
		mStartDateDisplay.setText(new StringBuilder().append(mDay).append("-").append(mMonth + 1).append("-").append(mYear).append(" "));
	}
	
	private TimePickerDialog.OnTimeSetListener mTimeSetListener = new TimePickerDialog.OnTimeSetListener() {
     //received when the user "sets" the TimePickerDialog in the dialog
                public void onTimeSet(TimePicker view, int hourOfDay, int min) {
                    mHour = hourOfDay;
                    mMinute = min;
            		updateTimeDisplay();
                  }
            };
            
    private TimePickerDialog.OnTimeSetListener mEndTimeSetListener = new TimePickerDialog.OnTimeSetListener() {
      //received when the user "sets" the TimePickerDialog in the dialog
        	public void onTimeSet(TimePicker view, int hourOfDay, int min) {
        	       eHour = hourOfDay;
        	       eMinute = min;
        	       updateEndTimeDisplay();
        	                  }
        	            };
            
		//Reformats the time as hh:mm
	void updateTimeDisplay(){
		mStartTimeDisplay.setText(new StringBuilder().append(mHour).append(":").append(mMinute));	
	}
	
	private void updateEndtDateDisplay() {
		mDateEnd.setText(new StringBuilder().append(eDay).append("-").append(eMonth + 1).append("-").append(eYear).append(" "));
	}
	
	//Reformats the time as hh:mm
	void updateEndTimeDisplay(){	
	mTimeEnd.setText(new StringBuilder().append(eHour).append(":").append(eMinute));	
}
	
	private void createAlarm(){
		
    	Intent i = new Intent(AlarmClock.ACTION_SET_ALARM); 
    	i.putExtra(AlarmClock.EXTRA_MESSAGE, mTitle.getText().toString()); 
    	i.putExtra(AlarmClock.EXTRA_HOUR, mHour - 1); 
    	i.putExtra(AlarmClock.EXTRA_MINUTES, mMinute);
    	i.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
    	i.putExtra(AlarmClock.EXTRA_RINGTONE, 0);
    	startActivity(i);
	}
	
	private boolean checkDate(){
		float endDate = saveEndDateInMillis();
		float startDate = saveGetDateInMillis();
		boolean dateOK;
		dateOK = true;
		
		if (endDate < startDate){
			dateOK = false;
		}
		return dateOK;
	}
	private boolean checkTime(){
		boolean timeOK;
		float endDate = saveEndDateInMillis();
		float startDate = saveGetDateInMillis();
		float startT = TimeUnit.MINUTES.toMillis(mMinute) + TimeUnit.HOURS.toMillis(mHour);
		float endT = TimeUnit.MINUTES.toMillis(eMinute) + TimeUnit.HOURS.toMillis(eHour);
		timeOK = true;
		
		if (endDate > startDate && endT < startT){
			timeOK = true;
		} else if (endT < startT) {
			timeOK = false;
		}
		return timeOK;
	}
	
}
