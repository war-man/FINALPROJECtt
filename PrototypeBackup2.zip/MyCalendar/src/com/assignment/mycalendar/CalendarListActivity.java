//11042712
//Isaac Kingsley Tyson-Seale
package com.assignment.mycalendar;

import java.text.SimpleDateFormat;

import com.assignment.mycalendar.R;
import com.assignment.mycalendar.calendardata.CalendarEntry;

import extra.MySimpleCursorAdapter;
import android.app.ListActivity;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.content.ContentUris;
import android.content.Intent;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ContextMenu.ContextMenuInfo;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

public class CalendarListActivity extends ListActivity {
	private static final String TAG = "ListActivity";
	private int mYear, mMonth, mDay; 
	private String mDate;
	
	//Called when activity starts
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		getActionBar().setHomeButtonEnabled(true);
		getActionBar().setDisplayHomeAsUpEnabled(true);
		setTitle("View All");
		
		// Get the Intent associated with this Activity
        Intent mIntent = getIntent();
		Log.i(TAG, "Calendar List Activity - got intent");
        // If there is no data associated with the Intent, sets the data to the default URI, which accesses or entries
        if (mIntent.getData() == null) {
        	mIntent.setData(CalendarEntry.EntryItem.CONTENT_URI);
    		Log.i(TAG, "Calendar List Activity 2");
        }   		
       
        // Create a new cursor by calling managedQuery.
		Cursor cursor = managedQuery(
				mIntent.getData(), 						// Use the default content URI for the provider.
            	CalendarEntry.EntryItem.LIST_PROJECTION,    					// Return the results of the table
                null,                             		// No where clause, returns all records.
                null,                             		// No where clause, no where column.
                CalendarEntry.EntryItem.DEFAULT_SORT_ORDER 
            );  
		Log.i(TAG, "Calendar List Activity - projection");
        
		//Log.i(TAG, "Long to String " + lng);
		// The names of the cursor columns to display in the view initialized to the description column
        String[] dataColumns = { CalendarEntry.EntryItem.COLUMN_NAME_TITLE, CalendarEntry.EntryItem.COLUMN_NAME_ENTRY_DATE} ;
        int[] viewIDs = { android.R.id.text1, android.R.id.text2 };

        
        // Create a new SimpleCursorAdapter
        // Creates the adapter for the ListView.

		SimpleCursorAdapter adapter
            = new MySimpleCursorAdapter(
                      this,                             // The Context for the ListView
                      R.layout.calendar_list_activity,      // Points to the XML for a list item
                      cursor,                           // The cursor to get items from
                      dataColumns,						// The array of Strings holding the names of the data columns to display	
                      viewIDs							// The array of resource ids used to display the data 
              );
              
		
        // set the new adapter as the list adapter
        setListAdapter(adapter);
        
        // Register for a context menu
        registerForContextMenu(getListView());
	}

	public static String getDate(float milliSeconds, String dateFormat) {
	    SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
	    return formatter.format(milliSeconds);
	}
	
	@Override
	//Create Options Menu
	public boolean onCreateOptionsMenu(Menu menu) {
		MenuInflater mInflater = getMenuInflater();
		mInflater.inflate(R.menu.calendar_view_option, menu);
		return true;
	}
	
    @Override
	//Create context Menu (Long press)
    public void onCreateContextMenu(ContextMenu cMenu, View view, ContextMenuInfo menuInfo) {
      super.onCreateContextMenu(cMenu, view, menuInfo);
      MenuInflater mInflater = getMenuInflater();
      mInflater.inflate(R.menu.calendar_entry_option, cMenu);
    }
	
	@Override
    public boolean onContextItemSelected(MenuItem mItem) {
        // The data from menu item.
        AdapterView.AdapterContextMenuInfo info;

        // Gets extra info from menu item.
        try {
            // puts data object from the item into AdapterView objects.
            info = (AdapterView.AdapterContextMenuInfo) mItem.getMenuInfo();
        } catch (ClassCastException e) {

            // error message
            Log.e(TAG, "bad menu item", e);

            return false;
        }
        // Appends the selected note's ID to the URI sent with the incoming Intent.
        Uri eURI = ContentUris.withAppendedId(getIntent().getData(), info.id);  	
        Log.i(TAG, "Entry deleted =" + info.id);
	      switch (mItem.getItemId()) {
	      case R.id.delete:
	    	  deleteEntryItem(eURI); 
	        return true;
	      default:
	        return super.onContextItemSelected(mItem);
	      }
    }	
	@Override
	public boolean onOptionsItemSelected(MenuItem mItem) {
		// add options to Menu
		switch (mItem.getItemId()) {
	    case R.id.menu_add:
	    	addCalendarEntry();
			return true;
	    case R.id.menu_month:
	    	monthView();
	    	return true;
		default:
			return super.onOptionsItemSelected(mItem);
		}
	}
	@Override
	public void onListItemClick(ListView listview, View view, int position, long id) {

	  	  Intent mIntent = new Intent(this, CalendarEntryActivity.class);
	  	  // add URI as Data for the Intent
	  	mIntent.setData(getIntent().getData()); 
	  	  // Put the ID of the entry item into the Intent
	  	mIntent.putExtra(Constants.CALENDAR_ID, id);
	  	  startActivity(mIntent);
	}

	private void addCalendarEntry() {	
	  	  Intent mIntent = new Intent(this, CalendarEntryActivity.class);
	  	  mIntent.setData(getIntent().getData()); 
	  	  mIntent.putExtra(Constants.CALENDAR_ID, Constants.CALENDAR_ITEM_UNDEFINED);		
	  	  startActivity(mIntent);
	}
	
	private void monthView() {	
	  	  Intent mIntent = new Intent(this, MyCalendarActivity.class);		
	  	  startActivity(mIntent);
	}
	
	private void deleteEntryItem(Uri eUri) {
		getContentResolver().delete(eUri, null, null);	
	}		
}