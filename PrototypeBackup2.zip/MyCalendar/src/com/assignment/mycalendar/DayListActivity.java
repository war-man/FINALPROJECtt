//11042712
//Isaac Kingsley Tyson-Seale
package com.assignment.mycalendar;

import java.text.SimpleDateFormat;

import com.assignment.mycalendar.R;
import com.assignment.mycalendar.calendardata.CalendarEntry;

import extra.MySimpleCursorAdapter;
import android.app.ListActivity;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.content.ContentUris;
import android.content.Intent;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ContextMenu.ContextMenuInfo;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

public class DayListActivity extends ListActivity {
	private static final String TAG = "DayListActivity";
	private String theDate;
	//Called when the activity starts
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Get the Intent associated with this Activity
        Intent mIntent = getIntent();
        theDate = mIntent.getStringExtra("datePassed"); //Date being passed to from calendar view to list view
		getActionBar().setHomeButtonEnabled(true);
		getActionBar().setDisplayHomeAsUpEnabled(true);
		setTitle("Viewing " + theDate);
		
		Log.i(TAG, "dla1");
        // If there is no data associated with the Intent, sets the data to the default URI
        if (mIntent.getData() == null) {
        	mIntent.setData(CalendarEntry.EntryItem.CONTENT_URI);
    		Log.i(TAG, "dla2");
        }   		
        String selection = CalendarEntry.EntryItem.COLUMN_NAME_START_DATE+"='" + theDate + "'";
        
        // Create new cursor by calling managedQuery.
		Cursor cursor = managedQuery(
				mIntent.getData(), 						// Use the default content URI for the provider.
            	CalendarEntry.EntryItem.LIST_PROJECTION,// Return the results of the table
            	selection,                             		// No where clause, returns all records.
            	null,                             		// No where clause, no where column.
                CalendarEntry.EntryItem.DEFAULT_SORT_ORDER        
            );  
		Log.i(TAG, "dla3 " );
        
		// The names of the cursor columns to display in the view initialized to the description column
        String[] dataColumns = { CalendarEntry.EntryItem.COLUMN_NAME_TITLE, CalendarEntry.EntryItem.COLUMN_NAME_ENTRY_DATE} ;
        int[] viewIDs = { android.R.id.text1, android.R.id.text2 };

        
        // Create a new SimpleCursorAdapter
        // Creates the adapter for the ListView.

		SimpleCursorAdapter adapter
            = new MySimpleCursorAdapter(
                      this,                             // The Context for the ListView
                      R.layout.calendar_list_activity,      // Points to the XML for a list item
                      cursor,                           // The cursor to get items from
                      dataColumns,						// The array of Strings holding the names of the data columns to display	
                      viewIDs							// The array of resource ids used to display the data 
              );
		
        // set the new adapter as the list adapter
        setListAdapter(adapter);
        
        // Register for a context menu
        registerForContextMenu(getListView());
	}

	public static String getDate(float milliSeconds, String dateFormat) {
	    SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
	    return formatter.format(milliSeconds);
	}
	
	@Override
	//Create Options Menu
	public boolean onCreateOptionsMenu(Menu menu) {
		MenuInflater mInflater = getMenuInflater();
		mInflater.inflate(R.menu.calendar_view_option, menu);
		return true;
	}
	
    @Override
	//Create context Menu (Long press)
    public void onCreateContextMenu(ContextMenu cMenu, View view, ContextMenuInfo menuInfo) {
      super.onCreateContextMenu(cMenu, view, menuInfo);
      MenuInflater mInflater = getMenuInflater();
      mInflater.inflate(R.menu.calendar_entry_option, cMenu);
    }
	
	@Override
    public boolean onContextItemSelected(MenuItem mItem) {
        // The data from  menu.
        AdapterView.AdapterContextMenuInfo info;

        // Gets extra info from menu item.
        try {
            // puts data object from the item into AdapterView objects.
            info = (AdapterView.AdapterContextMenuInfo) mItem.getMenuInfo();
        } catch (ClassCastException e) {

            // error message
            Log.e(TAG, "bad menu item", e);

            return false;
        }
        // Appends selected ID to the URI
        Uri eURI = ContentUris.withAppendedId(getIntent().getData(), info.id);  	
        Log.i(TAG, "Entry deleted =" + info.id);
	      switch (mItem.getItemId()) {
	      case R.id.delete:
	    	  deleteEntryItem(eURI); 
	        return true;
	      default:
	        return super.onContextItemSelected(mItem);
	      }
    }	
	@Override
	public boolean onOptionsItemSelected(MenuItem mItem) {
		// add options to the Menu
		switch (mItem.getItemId()) {
	    case R.id.menu_add:
	    	addCalendarEntry();
			return true;
	    case R.id.menu_month:
	    	monthView();
	    	return true;
		default:
			return super.onOptionsItemSelected(mItem);
		}
	}
	@Override
	public void onListItemClick(ListView listview, View view, int position, long id) {

	  	  Intent mIntent = new Intent(this, CalendarEntryActivity.class);
	  	  // add URI as Data for Intent
	  	mIntent.setData(getIntent().getData()); 
	  	  // Put ID of entry item into Intent
	  	mIntent.putExtra(Constants.CALENDAR_ID, id);
	  	  startActivity(mIntent);
	}

	private void addCalendarEntry() {	
	  	  Intent mIntent = new Intent(this, CalendarEntryActivity.class);
	  	mIntent.setData(getIntent().getData()); 
	  	mIntent.putExtra(Constants.CALENDAR_ID, Constants.CALENDAR_ITEM_UNDEFINED);		
	  	  startActivity(mIntent);
	}
	
	private void monthView() {	
	  	  Intent mIntent = new Intent(this, MyCalendarActivity.class);		
	  	  startActivity(mIntent);
	}
	
	private void deleteEntryItem(Uri eUri) {
		getContentResolver().delete(eUri, null, null);	
	}		
}