# TouristTrackingAssistant
This is a prototype app for providing treaking assistance to tourist. This project was developed for a final year project of Bachelor degree.
