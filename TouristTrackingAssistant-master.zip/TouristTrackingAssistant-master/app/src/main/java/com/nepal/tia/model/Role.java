package com.nepal.tia.model;

import java.io.Serializable;

public enum Role implements Serializable {
    ADMIN,
    USER
}
