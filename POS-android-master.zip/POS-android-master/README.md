# POS-android
POS for android application - Final Year Project
