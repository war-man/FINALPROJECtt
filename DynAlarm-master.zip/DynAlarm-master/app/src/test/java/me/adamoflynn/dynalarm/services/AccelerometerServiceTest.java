package me.adamoflynn.dynalarm.services;

/**
 * Created by Adam on 29/03/2016.
 */
public class AccelerometerServiceTest {

}
