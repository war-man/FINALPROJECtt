package android.net.http;

/**
 * Created by Adam on 04/05/2016.
 */
public class AndroidHttpClient {
}
