package com.example.shane.mainproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MoviesPage extends AppCompatActivity {
    DatabaseHelper myDB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movies_page);

        myDB = new DatabaseHelper(this);
    }


}
