package com.example.shane.mainproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class GamesPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_games_page);
    }
}
