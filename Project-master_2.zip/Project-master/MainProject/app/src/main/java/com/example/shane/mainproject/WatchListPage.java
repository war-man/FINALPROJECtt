package com.example.shane.mainproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class WatchListPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_watch_list_page);
    }
}
